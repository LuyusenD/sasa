<template>
  <div id="app" v-if="head==1">
   <!--公用头部 Header-->
    <sa-header ></sa-header>
    <router-view/>
    
<!--辅助功能-->
    <sa-rightFlxed></sa-rightFlxed>
    <sa-foot></sa-foot>
  </div>
  <div id="app" v-else>
    <router-view/>
  </div>
  
</template>

<script>
  
import header from '@/views/header.vue'
import rightFixed from '@/components/index/right_fixed.vue'
import foot from '@/views/foot.vue'
export default {
   data(){return{
     head:1
   }},
   components:{
    'sa-header':header,
    "sa-foot":foot,
    "sa-rightFlxed":rightFixed,
   },
   created(){
     let url = location.href.slice(22)
     if(url=="register" || url=="user_login"  )
       this.head=0
     else
       this.head=1
   }
}
</script>
<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
 
}
#nav {
  padding: 30px;
}

#nav a {
  font-weight: bold;
  color: #2c3e50;
}

#nav a.router-link-exact-active {
  color: #42b983;
}

</style>
