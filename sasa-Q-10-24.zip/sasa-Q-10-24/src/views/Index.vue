<template>
<div>
     
     <!--轮播图片 Carousel-->
      <sa-carouselsx></sa-carouselsx>
    <div class="box" id="shop" style="background:#f2f2f2;">
        <!--轮播后的第一个section 内容1 -->
        <div id="max_box">
            <sa-select1></sa-select1>
        <!--每日必看 Daylook-->
            <div><sa-daylook></sa-daylook></div>

        <!--限时特卖 Limitedoffer-->
            <sa-limitedoffer></sa-limitedoffer>

        <!--排行榜单 Order By-->
            <sa-ranking></sa-ranking>

        <!--楼层导航 Floor Guide-->
            <sa-leftFixed></sa-leftFixed>
            <br/>
        <!--新品栏目 New Arrlval-->
            <sa-newarrlval></sa-newarrlval>

        <!--公用页尾 All Foot-->
        
        </div>

     <!--拖拽商品-->   
        <div class="btm_Ckou d-flex ">
            <button class="btm_bn1">Shop</button>
            <button>Log in</button>
        </div>

     <!--下滑导航栏-->
        <div class="box_zhezao"></div>
    </div>
 
</div>
</template>
<script>
// @ is an alias to /src


import select1 from '@/components/index/select1.vue'
import carouselsx from '@/components/index/carouselsx.vue'
import daylook from '@/components/index/daylook.vue'
import limitedoffer from '@/components/index/limitedoffer.vue'
import ranking from '@/components/index/ranking.vue'
import newarrlval from '@/components/index/newarrlval.vue'
import leftFixed from '@/components/index/left_fixed.vue'

export default {
  data(){
     return {}
  },
  components: {
    'sa-carouselsx':carouselsx,
    "sa-daylook":daylook,
    "sa-limitedoffer":limitedoffer,
    "sa-ranking":ranking,
    "sa-newarrlval":newarrlval,
    "sa-leftFixed":leftFixed,
    "sa-select1":select1,
  }
}
</script>

<style scoped>
    #max_box{
        width:1366px;
        margin:0 auto;
    }
    /*.section_3{
        background:#F2F2F2 !important
    }*/
    #shop{
        margin: 0 auto;
        min-width: 1366px;
    }
</style>