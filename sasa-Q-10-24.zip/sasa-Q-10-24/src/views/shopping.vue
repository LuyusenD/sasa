<template>
<div>
<div class="section_1" id="section_1" v-cloak>
    <span><a href="index.html"> 首页 </a>/<a href="#"> 彩妆 </a>/<a href="#"> 美唇 </a>/<a href="#"> 唇膏 </a>/<a href="#"> 旅行口红套装 </a></span>
    <div class="row bg-white mt-3">
        <div class="col-5">
            <div class="content-img" id="content-img">
                <img src="static/img/body/Shopping_new.png"/>
                <div class="content-img-lg">
                    <img :src="p.img0"/>
                    <div id="op_div"></div>
                    <i></i>
                    <s></s>
                </div>
                <div id="op_mtk"></div>                     
                <div id="video">
                    <video :src="p.video" controls></video>
                </div>
                <div id="op_big_box">
                    <img :src="p.img0"/>
                </div>
                <div class="content-img-sm ">
                    <li v-for="img in img_arr" ><img :src="img"/></li>
                </div>
            </div>
        </div>        
        <div class="col-7">
            <div class="content-text mt-3">
                
                <div class="title ml-5">
                    <span>香港特快直送</span>
                    <span>零口关</span>
                    <span>包税</span>
                    <a href="#"><b>{{p.brand}}{{p.title}}</b></a>
                </div>
                <div class="price ml-5 mt-4">
                    <span>￥ {{p.price}}.00 </span>
                    <s>市场价{{p.yprice}}</s>
                    {{p.discount}}折
                </div>
                <div class="sales mt-5 ml-5">
                    <p title="香港特快直送商品满￥${emailprice} 免邮">
                        <span>订单促销</span>香港特快直送商品满￥{{p.emailprice}} 免邮
                    </p>
                    <p title="香港特快直送商品满￥${emailprice}减运费￥${semailprice}">
                        <span>订单促销</span>香港特快直送商品满￥{{p.emailprice}}减运费￥{{p.semailprice}}
                    </p>
                </div>
                <div class="details mt-4 ml-5">
                    <hr/>
                    <p>
                        <span>配送</span> 香港发货，香港直送时间为{{p.day}}个工作天
                    </p>
                    <p>
                        <span>运费</span> 满￥{{p.semailprice}}免运费
                    </p>
                    <p>
                        <span>税费</span> <a style="color:#EC3E7C">本商品包税，无需再额外缴纳。</a>如有疑问，请联系客服咨询。
                    </p>
                    <p>
                        <span>服务</span> <img src="static/img/body/shop3.png"/> 30日退换保证  <img src="static/img/body/shop2.png"/> 正品保障 <img src="static/img/body/shop1.png"/> 价格承诺
                    </p>
                    <hr/>
                </div>
                <div class="count ml-5">
                    数量: <button class="ml-3 mb-2" value="-">-</button><input type="text" value="1"/><button>+</button>
                    库存:  <span> {{p.inventory}}</span>
                    <p class="mt-4">
                        <a href="javascript:;"  @click="addUserShop" class="mr-5">加入购物车</a> <span>扫一扫加入购物车</span>
                    </p>
                </div>
                <div class="erweima"><img src="static/img/body/Shopping_erweima.png"/></div>
                <div class="grade ml-5 mt-5">
                    <span>评分
                        <i>
                            <img v-for="i in 5" src="static/img/body/shop11.png"/>
                        </i>
                    </span> <a href="#">(0人评价)</a>
                    <div>
                        <a href="#?"><img src="static/img/body/shop4.png"/>喜欢</a>
                        <p>
                            分享: <a href="#"><img src="static/img/body/shop7.png"/></a><a href="#"><img src="static/img/body/shop6.png"/></a>
                            <a href="#"><img src="static/img/body/shop8.png"/></a><a href="#"><img src="static/img/body/shop9.png"/></a>
                            <a href="#"><img src="static/img/body/shop10.png"/>
                            </a>
                        </p>
                    </div>
                </div>
                    
                
            </div>
        </div>
    </div>
</div>

<sp-like></sp-like>

<div class="section_3 row flex-nowrap " id="section_3">
    <div class="col-3 s3_list">
        <div class="s3_list_">
            <li>浏览记录</li>
            <ul>
                <li v-for="i in 5"><a href="#"><img src="static/img/body/Shopping_img_sm_3.jpg"/></a> <div><a href="#"><span>香港特快直送 零扣关</span> 圣罗兰 旅行口红套装 3件</a> <p>￥794.0 <s> ￥794.0</s></p></div></li>
            </ul>
        </div>
    </div>
    <div class="col-9 s3_content">
        <div class="s3_cont1">
            <li value="1">商品参数</li>
            <li value="2">商品详情</li>
            <li value="3">品牌故事</li>
            <a href="javascript:;">加入购物车</a>
            <span>￥{{p.price}}.0</span>
            
            <i></i>
        </div>
        <div class="s3_cont2 mt-4">
            <p>商品参数</p>
            <div class="s3_cont2_p">
                <p><span>商品编号：</span>{{p.shopId}}</p>
                <p><span>商品品牌：</span>{{p.brand}}</p>
                <p><span>商品名称：</span>{{p.title}}</p>
                <p><span>商品规格：</span>{{p.spec}}</p>
                <p><span>原产国家：</span>{{p.state}}（具体产地以收到实物为准）</p>
            </div>
        </div>
        <div class="s3_cont3 mt-4">
            <p>商品详情</p>
            <img v-for="i in xq_arr" :src="i"/>
        </div>
    </div>
</div>
</div>
</template>

<script scoped>
    import '@/../public/static/js/shopping.js'
    import '@/../public/static/css/shopping.css'
    import like from '@/components/shopping/like.vue'
    export default{
        data(){ return {img_arr:[],xq_arr:[],p:[],sid:null,uid:null,count:1} },
        created(){
            this.getlist()
        },
        methods:{
            getlist(){
                (async function(self){
                    var url= location.search,i=url.indexOf("sid"),
                        sid=parseInt(url.slice(i).split("=")[1]);
                        self.sid = sid
                    var res=await self.$http.get("http://127.0.0.1:4406/shopping?sid="+sid)
                    var p=res.data[0]
                    self.p=res.data[0]
                    self.img_arr=[p.img0,p.img1,p.img2,p.img3];
                    self.xq_arr=[p.xqimg0,p.xqimg1,p.xqimg2,p.xqimg3,p.xqimg4]
                })(this)
            },
            addUserShop(){
                var id = document.cookie.split("%")[0]
                if(id==''){
                    alert("请登录....")
                    this.$router.push('/user_login')
                    this.$router.go(0)
                    }
                this.uid = id;
                var shu = $('.count input').val();
                (async function(self){
                    var res=await self.$http.get(`http://127.0.0.1:4406/user/addUserShop?uid=${id}&sid=${self.sid}&count=${shu}`)
                })(this)
            }
        },
        components:{"sp-like":like}
    }
</script>

<style scoped>
    .bg-white{
        min-width: 1024px;
    }
    .s3_content{
        height:auto !important
    }
</style>



<!--
    




-->