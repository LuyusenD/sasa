<template>
<div id="register_box">
    <header>
        <a href="index.html"><img src="static/img/head/logo.png" class="mt-3"/></a>
        <span class="text-muted small ">已有莎莎网账号？ <a href="login_user.html">请登录</a></span>
    </header>
    <hr>
    <div id="content_bg"></div>
    <div id="register">
        <div class="row justify-content-center pt-3">
            <h3>sasa register</h3>
        </div>
        <div class="row mt-3 form_ alert_r">
            <input class="text" type="text" name='name' maxlength="20"/>
            <span>用户名</span>
            <div class="d-flex align-items-center">
                <i></i>
                <div></div>
            </div>
        </div>
        <div class="row mt-3 form_ alert_r">
            <input class="text" type="text" maxlength="11"/>
            <span>手机号</span>
            <div class="d-flex align-items-center">
                <i></i>
                <div></div>
            </div>
        </div>
        <div class="row mt-3 form_ alert_r">
            <input class="text" type="text"/>
            <button class="btn btn-outline-info checkbtn" disabled >获取验证码</button>
            <span>验证码</span>
            <div class="d-flex align-items-center">
                <i></i>
                <div></div>
            </div>
        </div>
        <div class="row mt-3 form_ alert_r">
            <input class="text pwd_index" type="password"/>
            <span>设置密码</span>
            <div class="d-flex align-items-center">
                <i></i>
                <div></div>
            </div>
        </div>
        <div class="row mt-3 form_ alert_r">
            <input class="text" type="password"/>
            <span>确认密码</span>
            <div class="d-flex align-items-center">
                <i></i>
                <div></div>
            </div>
        </div>
        <div class="row mt-2 small justify-content-center flex-column align-items-center">
            点击注册，表示您同意莎莎网 <a href="#">《服务协议及隐私声明》</a>
        </div>
        <div class="row mt-2">
            <a href="#" class="register_btn">同意协议并注册</a>
        </div>
    </div>
    <div class="text-center mt-3">Copyright 2000-2018 Sa Sa dot Com Limited 版权所有莎莎国际控股有限公司成员</div>

</div>
</template>

<script scoped>
    import axios from 'axios'
    import '@/../public/static/js/share.js'
    import '@/../public/static/js/user_register.js'
    import '@/../public/static/css/share.css'
    import '@/../public/static/css/register.css'
    export default{
        data(){ return {}},
        methods:{
            sss(){
                console.log(1)
            }
        }
    }
</script>

<style scoped>
    #register_box{
        min-width: 1024px;
    }
</style>
