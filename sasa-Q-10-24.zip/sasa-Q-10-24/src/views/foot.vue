<template>
 <div>
 
<div class="box" style="border-top: 1px solid #EEE;">
    <!--footer one-->
   <div class="footer_section_1 section_1">
       <ul class="list-unstyled d-flex flex-nowrap section_1_ul2 mt-4 justify-content-between">
           <li>
               <img src="static/img/body/1.png"/>
                <span class="spanall">
                    <h6 >香港特快直送</h6>
                </span>
           </li>
           <li>
               <img src="static/img/body/2.png"/>
                <span class="spanall">
                    <h6 class="pl-1">正品保证 </h6>
                </span>
           </li>
           <li>
               <img src="static/img/body/3.png"/>
                <span class="spanall">
                    <h6 class="pl-2">保税仓直送 </h6>
                </span>
           </li>
           <li>
               <img src="static/img/body/4.png"/>
                <span class="spanall">
                    <h6 class="pl-2">30天退换保证 </h6>
                </span>
           </li>
           <li>
               <img src="static/img/body/5.png"/>
                <span class="spanall">
                    <h6 class="pl-1">香港上市 <br/></h6>
                </span>
           </li>
       </ul>
   </div>
   <!--footer two-->
   <div class="footer_2 row ">
       <div class="col-8">
          <div class="row d-flex justify-content-between">
              <div class="font_8 d-flex align-items-center flex-column">
                  <a href="#"><h6 class="text-dark" style="font-weight: 600">新手上路</h6></a>
                  <a href="#">常见问题</a>
                  <a href="#">购物流程</a>
                  <a href="#">优惠卷说明</a>
                  <a href="#">联络我们</a>
              </div>
              <div class="font_8 d-flex align-items-center flex-column">
                  <a href="#"><h6 class="text-dark" style="font-weight: 600">付款方式</h6></a>
                  <a href="#">在线支付</a>
                  <a href="#">积分支付</a>
              </div>
              <div class="font_8 d-flex align-items-center flex-column">
                  <a href="#"><h6 class="text-dark" style="font-weight: 600">配送方式</h6></a>
                  <a href="#">配送说明</a>
                  <a href="#">追踪订单</a>
              </div>
              <div class="font_8 d-flex align-items-center flex-column">
                  <a href="#"><h6 class="text-dark" style="font-weight: 600">售后服务</h6></a>
                  <a href="#">正品保证</a>
                  <a href="#">价格承诺</a>
                  <a href="#">30日退换保证</a>
                  <a href="#">退款程序</a>
                  <a href="#">更改订单</a>
              </div>
              <div class="font_8 d-flex align-items-center flex-column">
                  <a href="#"><h6 class="text-dark" style="font-weight: 600">莎莎会员</h6></a>
                  <a href="#">积分奖赏</a>
                  <a href="#">VIP会员计划</a>
              </div>
          </div>
           <div class="row">
               <a href="#"><img src="static/img/body/footer_1.jpg"/></a>
           </div>
       </div>
       <div class="col-4 d-flex justify-content-around align-items-center">
           <div>
               <img src="static/img/body/wb-erweima.jpg" class="w-100"/>
               <h6>莎莎网官方微博</h6>
               <h6>@莎莎网</h6>
           </div>
           <div>
               <img src="static/img/body/wx-erweima.jpg" class="w-100"/>
               <h6>莎莎网官方微信</h6>
               <h6>ID:hksasadotcom</h6>
           </div>
       </div>

   </div>
   <div class="section_1 footer_3 mt-4 d-flex flex-column justify-content-center">
       <div class="d-flex justify-content-between font_8">
           <a href="#">关于莎莎</a>
           <a>|</a>
           <a href="#">使用条款</a>
           <a>|</a>
           <a href="#">隐私策略</a>
           <a>|</a>
           <a href="#">批发服务</a>
           <a>|</a>
           <a href="#">招商合作</a>
           <a>|</a>
           <a href="#">帮助中心</a>
           <a>|</a>
           <a href="#">港澳店铺推广</a>
           <a>|</a>
           <a href="#">人才招聘</a>
           <a>|</a>
           <a href="#">联络我们</a>
           <a>|</a>
           <a href="#">其他送货地区</a>
       </div>
       <p class="font_8 mt-2 mb-2">Copyright 2000-2018 Sa Sa dot Com Limited 版权所有莎莎国际控股有限公司成员</p>
   </div>
</div>

 </div>
</template>
<script>
    export default{
        name:"",
        created(){

        },
        data(){
            return {}
        },

    }
</script>
<style >
.box{
  background:#fff;
  min-width: 1366px;

}
.footer_section_1>ul{
    border-bottom:1px solid #eee;
    
}

.footer_2{
    padding-left:76px;
    padding-right:90px;
    margin-top: 16px;
}
.footer_2>div:nth-child(1)>div>div:nth-child(1){
    width:90px;
    height:165px;
}
.footer_2>div>div>div>a{
    color:#999;
    margin-top: 6px;
}
.footer_2>div>div>div>a:hover{
    text-decoration: none;
}
.footer_2>div:nth-child(2)>div{
    width:120px;
    height:195px;
    display: flex;
    align-items:center;
    flex-direction:column;
    margin-top: 30px;
}
.box>.footer_3{
    background:#000;
    height:100px;
    color:#fff;
}
.box>.footer_3>div{
    width:800px;
}
.box>.footer_3 a{
     color:#fff;
    text-decoration: none;
 }
 .spanall{
     position:relative;
     top:-1px !important;
     left:0px !important;
 }
 h6{
     display:inline
 }
</style>