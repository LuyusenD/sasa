<template>
<div >
<sa-header></sa-header>
<div class="barnn">
 <img style="width:100%" src="static/img/head/pubilc_barn.jpg">
</div> 
<div id="commoditys">

<div class="commodity_box"><!--box-->
    <!--页面标题图-->
    <div class="title_img"></div>
  <div class="ac_shop d-flex flex-wrap ">
     <div v-for="items in list" class="shop_ative "> 
      <div class="s3_content">
             <div class="s3_item">
             <div class="s3_item_1"><a href="shopping.html?sid=1"><img :src="items.img0"></a></div>
             <div class="s3_item_2 list-unstyled float-right" style="display: none; height: 253px; padding: 0px; margin: 0px; width: 87px; opacity: 1;">
             <li><img :src="items.img1"></li>
             <li><img :src="items.img2"></li>
             <li><img :src="items.img3"></li>
            </div>
            <div class="s3_item_3">
        <span class="text_F63D81 my_font_15r">￥{{items.price}}<s class="text-secondary small">  ￥355</s></span>
            <span class="text_C69A62">  {{ items.discount}}折</span>
            </div>
            <div class="s3_item_4">
             <span><b>香港特快直送 零扣关</b><b>COAST TOCOAST</b></span>
             <p class="my_font_9r"><a href="shopping.html?sid=1" class="nav-link p-0">{{items.brand}}</a></p>
             <p class="mt-4"></p>
             </div>
             <div class="s3_item_5">
             <a href="shopping.html?sid=1" style="display: none;">加入购物车</a>
             </div>
             </div>
             </div>
      </div>
   
   </div>
  <ul class="nav d-flex pageYm justify-content-end  mt-4 packg">
  <li  @click="prev()"  class="prev_nv nav-item border "><a class="nav-link disabled" href="">上一页</a></li>
  <li @click="pnoNum(i)" v-for="(val,i) in pageCount" class="nav-item border ml-1 "><a class="nav-link"  >{{i+1}}</a></li>
  <li @click="next()" class="nav-item border next_nv "><a  class="nav-link" >下一页</a></li>
  </ul>
 <sa-foot style="margin-left:-100px;"></sa-foot>
</div>

</div>

</div>
</template>

<script scoped>
import foot from '@/views/foot.vue'
import header from '@/views/header.vue'
     export default {
            name:"",
            components:{
                "sa-foot":foot,
                "sa-header":header,
            },
            created(){
              this.page()
            },
            data(){
                return{
                    pon:0,
                    list:[],
                    pageCount:[]
                }

            },methods:{
                prev(){
                     if(this.pon==0){
                           this.page(0)
                     }else{
                            this.pon--
                            this.page(this.pon)
                     }         
                },
                next(){
                   if(this.pon>=this.pageCount-1){
                      this.page(this.pageCount-1)
                   }else{
                      this.pon++
                      this.page(this.pon)
                   }
                },
                pnoNum(num){
                   this.pon=num;
                   this.page(num)
                },
                 page(pon=0){
                    var url=`http://127.0.0.1:4406/promo?pon=${pon}`
                     this.$http(url).then((res)=>{
                         this.list=res.data.products;
                         this.pageCount=res.data.pageCount
                         console.log(this.pon)
                     }) 

                 }
            }
     }
</script>
<style scoped>
 #commoditys{
     width:100% !important;
 }
    body{
    width:100%;
    height:auto;
     background:#F0F0F0 !important;
}
.shop_ative{

}
.shop_ative .s3_item_li{
    width:250px;
    height: 220px;
    position: relative;
}

.packg li a{
   color:rgb(211, 117, 117) !important;
   
}

.packg{
 position:relative;
 width:85%;
 height:40px;
 margin:0px auto;
 }
 .packg li{
 background:rgb(255, 247, 250);
 }
.shop_ative{
background:#F0F0F0 !important;

 width:280px;
 height: 500px;
 position: relative;
}
.ac_shop{
    width: 100%;
    position: relative;
    height: 1000px;

}
.s3_content{
    width:253px;
    height:480px;
    background:#fff;
    transition: .5s;
    margin-top: 10px;
    position:absolute;
    margin-right: 30px;
    left:20px;
}
a.disabled{
    pointer-events: none;
    opacity: .5;
}
/*search3 row position*/

/*search3 list position */
.s3_item_li{position:relative}

.sss{
    width:340px;
    height:520px;
    background:#fff;
    z-index: 2;
    box-shadow:0px 0px 20px 3px #CCCCCC;
}
.s3_item{
    position:relative
}

.s3_item img{
    width:100%;
    height:100%;
}
.s3_item_1>a>img{
     width:253px;
     height:253px;
 }
.s3_item_2{
    width:87px;
    height:253px;
    border:1px solid #eeeeee;
    position:absolute;
    top: 0;
    left:253px;
    display:none;
}
.s3_item_2>li{
    width:83px;
    height:83px;
    background:#fff;
    margin:1px auto;
}
.s3_item_2>li:hover{
    border:4px solid #C69A62;
}
.s3_item_3{
    height:48px;
    width:100%;
    border-bottom: 1px solid #eeeeee;
    border-top: 1px solid #eeeeee;
    padding: 6px;
}

.s3_item_4{
    height:106px;
    width:100%;
    padding: 6px;
    text-overflow:ellipsis;
    overflow:hidden;
    white-space:nowrap;
}
.s3_item_4>span>b:nth-child(1){
    color:#EE9C23;
}
.s3_item_5{
    height:113px;
    width:100%;
}
.s3_item_5 a{
    display:none;
    padding:10px 0;
    text-align:center;
    width: 210px;
    background:#EC3E7D;
    color:#fff;
    margin: 40px auto 0;

}
.s3_item_5 a:hover{
    color:#fff;
    background:#F06597;
}
.barnn{
    width: 100%;
    height: 420px;
  
    margin-bottom: 30px;
}
.commodity_box{
    margin: 0 auto;
    width: 1150px;
    position: relative;

}
#box_footer{
    position: relative;
left: -110px;
width: 1700px;
margin-bottom: 0px;
}
.title_img{
    width: auto;
    margin: 0 auto;
    height: 130px;
    background: url("../../public/static/img/head/pubilc_img2.png") no-repeat 50% ;

}/*item1*/
 .item1_warp {
    width: 267px;
    height: 470px;
   position: relative;
   overflow: hidden;
}
.item1_warp3{
    width: 267px;
    height: 470px;
   position: relative;
   overflow: hidden;
}

.item1_warp:hover{

}

 #item1_box{
     width: 100%;
     height: 100%;
 }
 .item_1,.item_2,.item_3{
     width: 270px;
     height: 472px;
     position: relative;
     box-shadow: 2px 2px 15px 1px #9febff;

 }
/*��Ʒͼ����*/
.promo_item1{
    width: 360px;
    height: 510px;
    box-shadow: 2px 2px 15px red;
    background: #ffffff;
    position: absolute;

}
.item_3 .promo_item1{
    width: 345px;
    height: 510px;
    background: #ffffff;
    position: absolute;
    left: -78px;

}

.item_2{
    background: #fff;
}
/*��Ʒ��ͼ*/
.item1_dimg{
    max-width: 268px;
    height:240px;
}
/*��ƷСͼ*/
.item1_simg{
    width:77px;
    height:77px;
    border-left: 1px solid #c4ddc9;
}
.activb{
    border: 4px solid #C69A62;
}
 .promo_item1 .item1_price{
     width:100%;
     margin-top: 1px;
     border-top: 2px solid #EEEEEE;
     border-bottom: 2px solid #EEEEEE;
     padding: 5px;
     font-size: 27px;
 }
.item_2 .item2_price2{
    width:100%;
    margin-top: 1px;
    border-top: 2px solid #EEEEEE;
    border-bottom: 2px solid #EEEEEE;
    padding: 5px;
    font-size: 27px;
}
.promo_item1 .item1_price span:nth-child(1),.item_2 .item2_price2 span:nth-child(1){
    color: #EC3E7D ;
}
.promo_item1 .item1_price span:nth-child(2),.item_2 .item2_price2 span:nth-child(2){
    font-size: 10px !important;
}
.promo_item1 .item1_price span:nth-child(3),.item_2 .item2_price2 span:nth-child(3){
    font-size: 15px !important;
}

.promo_item1 .item1_price .item1_sp3{
    position: relative;
    left: 50px;
}
.promo_item1 .item1_p1,.item_2 .item1_p1{
    color: #ee9c23;
    font-size: 13px;
    font-weight: bold;
    margin-left: 15px;
    margin-top: 7px;
}
.promo_item1 .item1_p1 span,.item_2 .item1_p1 span{
    margin-left: 7px;
    color:#3e3e3e !important;
}
.promo_item1 .item1_sp1,.item_2 .item1_sp1{
    position: relative;
    top:-16px;
    left: 15px;
    font-size: 13px;
    color: #3E3E3E;
}
 .promo_item1 .item1_p2,.item_2 .item1_p2{
     color:#3E3E3E;
     font-size:15px;
     margin-left: 15px;
 }
.promo_item1 .item1_p3,.item_2 .item1_p3{
    font-size: 6px;
    position: relative;
    top: -10px;
    left: 15px;
}
.promo_item1 button,.item_2 button{
    width: 225px;
    height: 45px;
    background:#EC3E7D;
    color: #FEFDFF;
    outline:none;
    position: relative;
    top: 13px;
    display: none;
}
.promo_item1 button:hover{
    background:#f06097;

}
</style>