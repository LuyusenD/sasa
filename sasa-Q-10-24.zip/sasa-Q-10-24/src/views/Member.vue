<template>
<div>

 <div style="">
     
    <div style="" class="select_bg"></div>
    <div class="select1"> 
        <div class="s_Tnav">
           <ul>
               <li>0 积分</li>
               <li>站内信</li>
               <li>手机</li>
               <li>电邮</li>
           </ul> 
       </div>
       <div class="s_Lnav">
           <div class="self_Inof">
                 <div class="tx_img"></div>
                 <span class="hone">177****2020213</span>
                 <p class="s_title">我的账户</p>
                 <div class="s_State">
                    <p>状态</p>
                    <ul>
                        <li><span></span><a href="#">我的订单</a></li>
                        <li><span></span><a href="#">我的积分</a></li>
                        <li><span></span><a href="#">优惠大全 </a></li>
                        <li><span></span><a href="#">站内消息</a></li>
                        <li><span></span><a href="#">我的收藏</a></li>
                        <li><span></span><a href="#">到货通知</a></li>
                        <li><span></span><a href="#">我的评价</a></li>
                        <li><span></span><a href="#">售后咨询</a></li>
                    </ul>
                    <p>个人资料管理</p>
                    <ul>
                        <li><span></span><a href="#">资料设置</a></li>
                        <li><span></span><a href="#">安全中心</a></li>
                        <li><span></span><a href="#">收货地址</a></li>
                        <li><span></span><a href="#">其他平台</a></li>
                      
                    </ul>
                    <p>VIP贵宾</p>
                    <ul>
                        <li><span></span><a href="#">VIP专享卡</a></li>
                        <li><span></span><a href="#">VIP贵宾卡</a></li>
                 </ul></div>
           </div>
       </div>
       <div class="s_body">
           <p class="b_title">
            <img src="" alt="">我的站内信
           </p>
           <hr width="90%" style="margin:0px auto;">
           <div class="b_meinfo">
            <p><span></span>&nbsp;&nbsp;&nbsp;个人资料</p>
            <form> 
                <div class="b_input"><div class="b_border">邮箱</div><input        name="email" type="text"></div>    
                <br>
                <div class="b_input"><div class="b_border">姓名</div><input name="name"        type="text"></div>
                <br>
                <div class="b_input"><div class="b_border">手机号码</div><input        type="text"></div>   
                <br> 
                <div class="b_input"><div class="b_border">地址</div><input        name="address" type="text"></div>    
             </form>
              <div class="age"><input name="age" type="radio" value="1"><img src="../../public/static/img/member/man.png"><input type="radio" name="age" value="0"><img src="../../public/static/img/member/nv.png" alt=""></div>
              <p style="margin-left:5px;margin-top:10px;">
              <span></span>&nbsp;&nbsp;&nbsp;皮肤类型
              </p>
              <div class="b_Pclass">
                 <div><input name="b_pcl" type="radio">干性皮肤</div>
                 <div><input name="b_pcl" type="radio">中性皮肤</div>
                 <div><input name="b_pcl" type="radio">混合性偏干皮肤</div>
                 <div ><input name="b_pcl" type="radio">混合性偏干皮肤</div><br><br>
                 <div id="xz"><input name="b_pcl" type="radio">混合性偏干皮肤</div>
              </div> 
              </div> 
               <button class="pi_tj">Submit</button>
           
           </div>
       </div>
     </div>
 </div>
</template>

<script>
     export default{
         name:"",
         created(){
           if(document.cookie==''){
             alert('请登录.....')
             this.$router.push("user_login")

            }
         },
           components:{
         },
         methods:{

         },
         data(){
             return{}
         },
         mounted(){
           console.log($('#BleftX').hide())
         }
     }
</script>

<style scoped>

ul {
  list-style: none; }
  
body {
  background: #f7f7f7 !important; }

.left_Cwh {
  display: none; }

.all_type:hover ~ .BleftX > .left_Cwh {
  display: block !important; }

.BleftX:hover .left_Cwh {
  display: block !important; }
.user_img img{
  width: 100%;
  height: 100%;
  border-radius: 100%;
} 
.user_ico{
  width: 220px;
  position: absolute;
  height: 100px;
  left: 120px;
  color: #bb2a2a;
  top:29px;
  display: none;
  background: rgb(243, 243, 243);
  user-select: none;

}
.user_ico .font_money{
  position: relative;
  left:25px;
  font-size: 12px;
  color: #bb2a2a;
  
  top:25px;
}
.user_ico .font_info{
position: absolute;
left:60px;
top: 80px;
font-size: 2px !important;
color:#c28888;

}
.user_ico .user_img{
  width: 70px;
  position: relative;
  height: 70px;
  left: 10px;
  display: inline-block;
  top:10px;
  border-radius: 50%;
  background: #ec3e7d;
}
.user_ico .font_vip{
  position: absolute;
  top:25px;
  left:95px;
}
.select_bg {
  width: 100%;
  min-width: 1366px;
  height: 214px;
  background-image: url("../../public/static/img/member/men.jpg");
  position: relative; }

.select1 {
  width: 100%;
  height: 690px;
  position: relative;
  top: -35px; }
  .select1 .s_Tnav {
    opacity: .7;
    width: 100%;
    min-width: 1366px;
    height: 35px;
    background: #ffffff; }
    .select1 .s_Tnav ul {
      display: flex;
      list-style: none;
      justify-content: center; }
      .select1 .s_Tnav ul li {
        border-right: 1px solid #000000;
        margin-top: 7px;
        padding: 0px 30px; }
      .select1 .s_Tnav ul li:nth-child(4) {
        border: none; }
  .select1 .s_Lnav {
    width: 234px;
    height: 710px;
    position: relative;
    left: 200px;
    top: -80px;
    background: #494F4F; }
    .select1 .s_Lnav a {
      color: #d6d6d6 !important; }
      .select1 .s_Lnav a:hover {
        text-decoration: none !important; }
    .select1 .s_Lnav .self_Inof {
      width: 100%;
      height: 78px;
      background: #404040; }
      .select1 .s_Lnav .self_Inof .tx_img {
        width: 50px;
        height: 50px;
        background: #ffffff;
        position: relative;
        left: 30px;
        top: 14px; }
      .select1 .s_Lnav .self_Inof .hone{
        position: relative;
        left: 100px !important;
        }
        .select1 .s_Lnav .self_Inof .tx_img img{
          width: 100%;
          height: 100%;
        }
      .select1 .s_Lnav .self_Inof span {
        position: relative;
        left: 90px;
        top: -25px;
        color: #ffffff;
        font-size: 10px; }
      .select1 .s_Lnav .self_Inof .s_title {
        color: #D5D7CE;
        margin-left: 40px;
        margin-top: 30px;
        font-size: 17px; }
      .select1 .s_Lnav .self_Inof .s_State {
        position:relative;
        left:61px; 
        }
        .select1 .s_Lnav .self_Inof .s_State p {
          color: #869BA7;
          font-size: 14px; }
        .select1 .s_Lnav .self_Inof .s_State li {
          color: #d6d6d6;
          font-size: 14px;
          padding: 3px; }
        .select1 .s_Lnav .self_Inof .s_State span {
          display: inline-block;
          width: 17px; }
  .select1 .s_body {
    width: 680px;
    height: 595px;
    border: 1px solid #fcfcfc;
    background: #fffefe !important;
    position: relative;
    left: 462px;
    top: -680px; }
    .select1 .s_body button {
      background: #1AAB8A;
      outline: none;
      color: #fffefe;
      height: 50px;
      cursor: pointer;
      padding: 0 3em;
      position: relative;
      border: none;
      font-size: 1.6em;
      left: 200px;
      top: 50px; }
    .select1 .s_body p:nth-child(1) {
      margin-top: 30px;
      margin-left: 0px !important;
      color: #7f8b8b;
      font-weight: bold; }
    .select1 .s_body .b_meinfo .b_Pclass {
      font-size: 10px;
      color: #aaa2a2;
      position:relative;
      left:50px;
      
       }
      .select1 .s_body .b_meinfo .b_Pclass div {
        display: inline-block;
        margin-right: 10px; }
      .select1 .s_body .b_meinfo .b_Pclass input {
        margin-right: 8px }
    .select1 .s_body .b_meinfo span:nth-child(1) {
      display: inline-block;
      width: 7px;
      height: 18px;
      position: relative;
      top: 4px;
      left: 5px;
      background: #494F4F;
      opacity: .9; }
    .select1 .s_body .b_meinfo p {
      position: relative;
      color: #869BA7;
      left:0px; 
      top:-15px;
      }
    .select1 .s_body .b_meinfo .age {
      position: relative;
      left:270px;
      width:200px;
      top: -150px; }
      .select1 .s_body .b_meinfo .age img {
        position: relative;
        top: -3px;
        z-index:1;
        left: 5px; }
      .select1 .s_body .b_meinfo .age input {
       z-index:2;
        margin-left: 30px;
        background: navy; }
    .select1 .s_body .b_meinfo .b_input {
      width: 240px;
      height: 35px;
      border: 1px solid	#c3caca;
      margin-left: 34px;
      box-shadow: 0px 0px 6px 0px #fcfcfc; }
      .select1 .s_body .b_meinfo .b_input input {
        height: 31px;
        outline: none;
        position: relative;
        top: -1px;
        border: 0px;
        font-size: 10px;
        color: #494F4F; }
    .select1 .s_body .b_meinfo .b_border {
      display: inline-block;
      text-align: center;
      line-height: 35px;
      width: 90px;
      height: 33px;
      font-size: 14px;
      background: #ffffff;
      border: 1px solid #ccccc9;
      color: #788888;
      font-size: 10px; }
      .select1 .s_body .b_meinfo .b_border:hover {
        border: 1px solid #eaf6fd; }

.b_input:before {
  content: '';
  position: absolute;
  top: 5;
  left: 35px;
  height: 1px;
  z-index: 5;
  width: 0;
  background: #ec506a;
  transition: 400ms ease all; }

.b_input:hover:before {
  width: 240px;
  transition: 800ms ease all; }

.pi_tj{
    position:relative;
    left:140px !important;
}
.pi_tj:before, .pi_tj:after {
  content: '';
  position: absolute;
  top: 0;
  right: 0;
  height: 3px;
  width: 0;
  background: #c2c2c0;
  transition: 400ms ease all; }

.pi_tj:after {
  right: inherit;
  top: inherit;
  left: 0;
  bottom: 0; }

.pi_tj:hover:before, .pi_tj:hover:after {
  width: 100%;
  transition: 800ms ease all; }

#box_footer {
  position: relative;
  top: -620px; }
#xz{
    position:relative;
    left:0px;
}

</style>