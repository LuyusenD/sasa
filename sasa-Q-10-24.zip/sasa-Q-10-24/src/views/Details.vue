<template>
    <div id="Details_box">
        <div id="search_1">
            <img src="static/img/shop_list_img/bg_shop.jpg">
        </div>
        <div id="search_2"></div>
        <div id="search3">
            <div id="search_3" class="">
            <div class="row">
                <div class="col-3 pl-4">
                <ul class="nav flex-column search_3_nav">
                    <li class="nav-item pl-4 pt-3"><h4>商品分类</h4> </li>
                    <li class="nav-item all_listshop pl-4"><a href="#"  @click.prevent="updateList('显示所有商品')">显示所有商品</a></li>
                    <li class="nav-item pl-4 s3_opacity">
                        <a href="#null" data-toggle="" class="s3_opacity_li">所有列表 <span class="s3_opacity_span"><img src="static/img/body/search_3_opacity_sjx.png" class="s3_opacity_img"/></span></a>
                        <div class="s3_opacity_list">
                            <div class="pl-4 mt-1" @click.prevent="updateList('面部保养')"><a href="#">>&nbsp;&nbsp;&nbsp; 面部保养</a></div>
                            <div class="pl-4 mt-1" @click.prevent="updateList('彩妆')"><a href="#">>&nbsp;&nbsp;&nbsp; 彩妆</a></div>
                            <div class="pl-4 mt-1" @click.prevent="updateList('香水')"><a href="#">>&nbsp;&nbsp;&nbsp; 香水</a></div>
                            <div class="pl-4 mt-1" @click.prevent="updateList('健康')"><a href="#">>&nbsp;&nbsp;&nbsp; 健康</a></div>
                            <div class="pl-4 mt-1" @click.prevent="updateList('个人护理')"><a href="#">>&nbsp;&nbsp;&nbsp; 个人护理</a></div>
                            <div class="pl-4 mt-1" @click.prevent="updateList('男人专区')"><a href="#">>&nbsp;&nbsp;&nbsp; 男人专区</a></div>
                            <div class="pl-4 mt-1" @click.prevent="updateList('婴儿护理专区')"><a href="#">>&nbsp;&nbsp;&nbsp; 婴儿护理专区</a></div>
                        </div>
                    </li>
                </ul>
                </div>
                <div class="col-9 listshop_content">
                <div class="nav_shop">
                    <ul class="list-unstyled">
                        <li class="ml_s" @click="ordeby(0)">销量  <q class="mt_s"></q></li>
                        <li class="ml_s" @click="ordeby(1)">折扣 <q class="mt_s"></q></li>
                        <li class="ml_s" @click="ordeby(2)">价格  <q class="mt_s"></q></li>
                        <li class="ml_s" @click="ordeby(3)">上架时间 <q class="mt_s"></q></li>
                    </ul>
                </div>
                <div class="ac_shop ">
                    <todo></todo>
                    
                </div>
                
                </div>
            </div>
        </div>    
        </div> 
    </div>
</template>

<script scoped>
    import '@/../public/static/css/Details.css'
    import '@/../public/static/js/Details.js'
    import todo from '@/components/details/todo.vue'
    import axios from 'axios'        
    export default{
        data(){return{}},
        created(){},
        methods:{
            updateList(vals){
                this.$children[0].updateList(vals)
            }

        },
        components:{"todo":todo}
    }
</script>

<style scoped>
    #search_1>img{
        width: 100%;
        height:100%;
    }
    #search3{
        width: 79%;
        margin: 10px auto 0;
        min-width:1172px
    }
    #search_2,#search_1{
        min-width:1172px
    }
</style>