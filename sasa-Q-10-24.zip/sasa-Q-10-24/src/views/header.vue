<template>
<div id="">
   <div class="box">
    <header>
        <nav id="navbar" class="navbar " >
            <!--导航栏左边-->
           <span class="navbar-brand my_font_8r">欢迎光临莎莎网！&nbsp;&nbsp;&nbsp;
               <a v-if="!istrue" href="/user_login">登录</a>
               <span v-if="!istrue">或</span>
               <span v-if="istrue">{{username}} <a href="/" @click="quit_user()">退出</a></span>
               <a v-if="!istrue" href="/register">免费注册</a>
           </span>
            <!--导航栏右边-->
            <ul class="navbar-nav flex-row my_font_8r">
                <li><a href="/Member">我的账户 ﹀</a>
                </li>
                <li><a href="/Member"><img class="nav_ico1"  src="" alt=""/>我的收藏</a></li>
                <li><a href="/Member">我的站内信</a></li>
                <li><a href="/Member">积分中心</a></li>
                <li><a href="#">Global site</a></li>
                <li class="d-flex">
                    <a href="#">关注我们</a>
                    <a href="#" class="nav_weibo ml-2"></a>
                    <a href="#" class="nav_weixin ml-2"></a>
                </li>
            </ul>
        </nav>
        <div class="header_search">
            <a href="#"><img src="" class="mt-4"/></a>
            <div class="header_search_btn mt-3">
                <div>
                    <input type="text" placeholder="JMsolution"/>
                    <button id="search_top" class="text-white ">搜索</button>
                </div>
                <ul class="nav">
                    <li class="nav-item"><a href="/shopping?sid=5">SK-LL</a></li>
                    <li class="nav-item"><a href="/shopping?sid=34">奥迪</a></li>
                    <li class="nav-item"><a href="/shopping?sid=38">伊丽莎白雅顿</a></li>
                    <li class="nav-item"><a href="/shopping?sid=52">Plantur</a></li>
                    <li class="nav-item"><a href="/shopping?sid=14">ILISYA</a></li>
                    <li class="nav-item"><a href="/shopping?sid=42">山野里</a></li>
                    <li class="nav-item"><a href="/shopping?sid=4">雪花秀</a></li>
                </ul>
            </div>
        </div>
    </header>
</div>
<div id="box_body">
 <div v-if="shop_car"></div>
 <div id="boxxx" v-else>
    <div class="d-inline-block all_type bg-dark"><p class="d-inline-block allist_ico navbar-dark"><span class="  navbar-toggler-icon"></span></p><p class="d-inline-block ">全部类型</p></div>
    <ul class="clear my_nav  d-inline-block list-unstyled ">
        <li class=""><a class="" href="promo.html"><img src="" alt=""/></a></li>
        <li class=""><a class="" href="#">面部护肤</a></li>
        <li class=""><a class="" href="#">彩妆</a></li>
        <li class=""><a class="" href="#">限时特卖</a><span class="hop_ico"></span></li>
        <li class=""><a class="" href="#">贵宾专享</a></li>
        <li class=""><a class="" href="#">清仓特卖</a></li>
        <li class=""><a class="" href="#">所有品牌</a><span class="dropdown-toggle dropdown_ico "></span></li>
    </ul>
    <div v-if="index" class="BleftX" id="BleftX">
        <!--全部分类-->
        <!--分类列表-->
        <ul class="list-unstyled left_Cwh">
            <!--li分类内容-->
            <!--列表内容-->
            <li class=" list_bgimg category-nav-item-1 selfclass list_bgimg ">
                <!--列表图标-->
                <span class="list_ico"></span>
                <span @click="push_details_(1)">面部护肤</span>
                <!--列表内容-->
                <div  class="class_Contents ">

                    <div>
                        <ul class="list-unstyled small">
                            <!--ajax 请求 导航栏-->
                            <li class="border-0 ">
	                			<h6 class="text-muted">{{title[0]}}</h6>
	                			<router-link v-for="(item,i) in list[0]" to="" @click="push_details_(1)">{{item}}</router-link>
	                		</li>
                            <li class="border-0 ">
	                			<h6 class="text-muted">{{title[10]}}</h6>
	                			<router-link v-for="(item,i) in list[10]" to="" @click="push_details_(1)">{{item}}</router-link>
	                		</li>
                            <li class="border-0 ">
	                			<h6 class="text-muted">颈部护理</h6>
	                			<router-link v-for="(item,i) in list[1]" to="" @click="push_details_(1)">{{item}}</router-link>
	                		</li>
                            <li class="border-0 ">
	                			<h6 class="text-muted">{{title[2]}}</h6>
	                			<router-link v-for="(item,i) in list[2]" to="" @click="push_details_(1)">{{item}}</router-link>
	                		</li>
                            <li class="border-0 ">
	                			<h6 class="text-muted">{{title[3]}}</h6>
	                			<router-link v-for="(item,i) in list[3]" to="" @click="push_details_(1)">{{item}}</router-link>
	                		</li>
                       
                    
                        </ul>
                    </div>
                </div>
                <span class="list_prverWhitico"></span>
            </li>
            <li class=" list_bgimg1 category-nav-item-1 selfclass  list_bgimg ">
                <span class="list_ico1"></span>
                <span @click="push_details_(2)">彩妆</span>
                <!--分类内容-->
                <div  class="class_Contents ">
                    <div class="   ">
                        <ul class="list-unstyled   small   ">
                             <li class="border-0 ">
	                			<h6 class="text-muted">精华护肤</h6>
	                			<a v-for="(item,i) in list[4]" @click="push_details_(2)">{{item}}</a>
	                		</li>
                         <li class="border-0 ">
	                			<h6 class="text-muted">卸掉污迹</h6>
	                			<a  v-for="items in list[5]" @click="push_details_(2)">{{items}}</a>
	                		</li>
                         <li class="border-0 ">
	                			<h6 class="text-muted">{{title[6]}}</h6>
	                			<a  v-for="items in list[6]" @click="push_details_(2)">{{items}}</a>
	                		</li>
                         <li class="border-0 ">
	                			<h6 class="text-muted">{{title[7]}}</h6>
	                			<a  v-for="items in list[7]" @click="push_details_(2)">{{items}}</a>
	                		</li>
                         <li class="border-0 ">
	                			<h6 class="text-muted">其他类型</h6>
	                			<a  v-for="items in list[8]" @click="push_details_(2)">{{items}}</a>
	                		</li>
                        
                        </ul>
                    </div>
                </div>
                <span class="list_prverWhitico"></span>
            </li>
            <li class=" list_bgimg2 category-nav-item-1 selfclass list_bgimg ">
                <span class="list_ico2"></span>
                <span @click="push_details_(3)">香水</span>
                <!--分类内容-->
                <div  class="class_Contents ">
                    <div class="  ">
                        <ul class="list-unstyled  small   ">
                             <!--ajax 请求 导航栏-->
                               <li class="border-0 ">
	                			<h6 class="text-muted">{{title[9]}}</h6>
	                			<a  v-for="items in list[9]" @click="push_details_(3)">{{items}}</a>
	                		</li>
                        </ul>
                    </div>
                </div>
                <span class="list_prverWhitico"></span>
            </li>
            <li class=" list_bgimg3 category-nav-item-1 selfclass list_bgimg ">
                <span class="list_ico3"></span>
                <span @click="push_details_(4)">健康美肌</span>
                <!--分类内容-->
                <div  class="class_Contents ">

                    <div class="  ">
                        <ul class="list-unstyled  small   ">
                              <li class="border-0 ">
	                			<h6 class="text-muted">{{title[10]}}</h6>
	                			<a  v-for="items in list[10]" @click="push_details_(4)">{{items}}</a>
	                		
	                		</li>
                        </ul>
                    </div>
                </div>
                <span class="list_prverWhitico"></span>
            </li>
            <li class=" list_bgimg4 category-nav-item-1 selfclass list_bgimg ">
                <span class="list_ico4"></span>
                <span >纤体美胸</span>
                <!--分类内容-->
                <div  class="class_Contents ">

                    <div class="  ">
                        <ul class="list-unstyled  small   ">
                          <li class="border-0 ">
	                			<h6 class="text-muted">{{title[11]}}</h6>
	                			<a  v-for="items in list[11]" href="">{{items}}</a>
	                		</li>
                        </ul>
                    </div>
                </div>
                <span class="list_prverWhitico"></span>
            </li>
            <li class=" list_bgimg5 category-nav-item-1 selfclass  list_bgimg ">
                <span class="list_ico5"></span>
                <span @click="push_details_(5)">个人护理</span>
                <!--分类内容-->
                <div  class="class_Contents ">

                    <div class="  ">
                        <ul class="list-unstyled  small   ">
                             <li class="border-0 ">
	                			<h6 class="text-muted">{{title[12]}}</h6>
	                			<a  v-for="items in list[12]" @click="push_details_(5)">{{items}}</a>
	                		
	                		</li>
                             <li class="border-0 ">
	                			<h6 class="text-muted">颈部护理</h6>
	                			<a  v-for="items in list[1]" @click="push_details_(5)">{{items}}</a>
	                		
	                		</li>
                        </ul>
                    </div>
                </div>
                <span class="list_prverWhitico"></span>
            </li>
            <li class=" list_bgimg6 category-nav-item-1 selfclass list_bgimg ">
                <span class="list_ico6"></span>
                <span @click="push_details_(6)">男士专区</span>
                <!--分类内容-->
                <div  class="class_Contents ">

                    <div class="  ">
                        <ul class="list-unstyled  small   ">
                   <li class="border-0 ">
	                			<h6 class="text-muted">{{title[13]}}</h6>
	                			<a  v-for="items in list[13]"  @click="push_details_(6)">{{items}}</a>
	                		</li>
                        </ul>
                    </div>
                </div>
                <span class="list_prverWhitico"></span>
            </li>
            <li class=" list_bgimg7 category-nav-item-1 selfclass  list_bgimg ">
                <span class="list_ico7"></span>
                <span @click="push_details_(7)">孕婴护理</span>
                <!--分类内容-->
                <div   class="class_Contents ">

                    <div class=" ">
                        <ul class="list-unstyled  small   ">
                             <li  class="border-0 ">
	                			<h6 id="t6s" class="attr_huli text-muted">{{title[14]}}</h6>
	                			<a   v-for="items in list[14]"  @click="push_details_(7)">{{items}}</a>
	                		</li>
                        </ul>
                    </div>
                </div>
                <span class="list_prverWhitico"></span>
            </li>

        </ul>
    </div>
    <div v-else></div>
  </div>
  
</div>


</div>
</template>

<script>
    /*.left_Cwh{display:none}*/

    export default {
        name:"daylook",
        data(){
            return {
                list:[],
                title:[],
                username:[],
                istrue:false,
                index:false,
                shop_car:false
            }
        },
        methods:{
            getuname(){
                var uanem=decodeURI(document.cookie).split("|");
                this.username=uanem[1];
                if(this.username){
                     this.istrue=true;
                }
            },
            getheader(){
              (async function(self){
          var res=await self.$http.get("http://127.0.0.1:4406/index/list_nav",{
               })
               self.list=res.data;
               for(var i=0;i<res.data.length;i++){
                   res.data[i].lid='';
                   self.title.push(res.data[i].title);
                 
                  
               }
               })(this)
               
            },
            quit_user(){
                //this.$router.go(0)
                document.cookie='';
            },
            push_details_(i){
                sessionStorage["details"] = `${i}`
                this.$router.push("/Details")
                this.$router.go(0)
            }
        },
        created(){
         this.getheader();
         this.getuname();
        location.href.slice(22)==''?this.index=true:this.index=false;
        location.href.slice(22,30)=='shop_car'?this.shop_car=true:this.shop_car=false;
        }
    } 
</script>

<style scoped>
.left_Cwh>li:hover{
	background:#fff;
	transition:.7s;
}
.left_Cwh>li:hover span:nth-child(2){color:#FA3778}
.my_font_8r{font-size: .8rem}
.my_font_9r{font-size: .8rem !important; }
.my_font_15r{font-size: 1.5rem !important;}
.my_font_30r{font-size: 3rem !important;}
.text_F63D81{color:#F63D81 !important;}
.text_C69A62{color:#C69A62 !important;}
.my_border_pink{background:#EE97B7; height:2px;}
.box{
  width:100%;
  min-width: 1366px;
  height:140px;
}
#box_body{
  text-align:center
}
header{
    background:#fff !important;
    height:140px;
}
/*ͷ��nav*/
header>nav{
    height:32px;
    background: #f2f2f2;
    border:1px solid #e5e5e5;
}
/*nav���ұ߾�*/
span.my_font_8r{margin-left:58px}
header .navbar{
position:relative;
left:-77px;
width:105%;
padding:0 1rem !important;
}

.header_search_btn{
    width: 800px;}
/*nav a��ǩ��ɫ*/
.navbar>span>a,#nav_li_one li>a:hover{
    color:#EC3E7D;
    text-decoration: none;
}
/*nav ���б���ʽ*/
header .navbar-nav>li{
    padding-left:14px;
    padding-right:14px;
    line-height:32px;
    position:relative;
    right:32px;
}
/*nav ���б�������*/
header .navbar-nav>li:hover{
    background:#fff;
}
/*nav ���б�΢�� ΢��ͼ����*/
.nav_weixin,.nav_weibo{
    display:block;
    width: 20px;
    height:32px;
}
/*nav ΢��΢������ͼƬ����λ��*/
.nav_weibo{
background:url(../../public/static/img/head/topicon.png) no-repeat 0px -14px;
}
.nav_weixin{
    background:url(../../public/static/img/head/topicon.png) no-repeat 0px -14px;
    
}
/*nav ��������ʽ*/
header .navbar-nav>li>a{display:block;line-height:32px}
header .navbar-nav>li a,.navbar>span,.my_gray{
    color:#6C6C6C;
}
header .navbar-nav>li a:hover{
    text-decoration: none;
}
#nav_li_one{
    position:absolute;
    left:0;
    top:40px;
    font-size: .9rem;
    width:104px;
    box-shadow:0 2px 1px 1px  #cccccc;
    background:#fff;
    z-index: 1;
    display:none;
}
.box>header>.navbar>.navbar-nav>li:first-child:hover #nav_li_one{
    display:block
}
#nav_li_one li{margin-top:6px;}

/*header - search - logo */
.header_search{
    height: 96px;
    z-index: 0;
}




.clip{
    position:relative;
    width:170px;
    height:62px;
}
.clip>a{
    display:block;
    position:absolute;
    top: 16px;
    padding: 10px;
}
.clip>a::after,.clip>a::before{
    position: absolute;
    top: 0;
    left:0;
    content:"";
    border:2px solid #F63D81;
    width:190px;
    height:62px;
    animation:clipAll 4s infinite linear;
}
.clip>a::before{
    animation-delay: 2s;
}
@keyframes clipAll{
    0%,100%{
        clip: rect(0px,190px,62px,187px);
    }
    25%{
        clip: rect(0px,190px,3px,0px);
    }
    50%{
        clip: rect(0px,3px,62px,0px);
    }
    75%{
        clip: rect(59px,190px,62px,0px);
    }
}
.header_search_btn>div>input{
    border:2px solid #ec3e7d;
    width:350px;
    outline: none;
    padding: 4px 0 4px 10px;
    color: #999999;
}
.section_1{
    padding-left:76px;
    padding-right:90px;
    margin-top: 16px;
}
.header_search_btn>div>button{
    position:relative;
    left:-10px;
    border:2px solid #ec3e7d;
    background: #ec3e7d;
    width:80px;
    outline: none;
    padding: 4px 0;
}
.header_search_btn>div{
    position:relative;
    top:-15px;
    left:530px;

}
.header_search_btn>ul{
    position:relative;
    top:-4px;
    left:534px;
}
.header_search_btn>.nav>li a{
    color: #aaaaaa;
}
.header_search_btn>.nav>li a:hover{
    text-decoration: none;
}
.header_search_btn>.nav>li{
    padding:0 8px;
    border-right: 1px solid #aaaaaa;
    height:14px;
    line-height: 14px;
    font-size: .8rem;
}
.header_search_btn>.nav>li:last-child{
    border:0;
}
/*����������*/
#float_search{
    display:none;
    background: #fefdff;
    position: fixed;
    z-index: 101;
    overflow:hidden;
    height: 50px;
    width: 100%;
    top: 0%;
    border-bottom: 2px solid #EC3E7D;
    box-shadow: 0px 0px 20px 0px  #EC3E7D;

}
#float_search .header_search1{
    position: relative;
    top: -15px;
}
#float_search .header_search1 .header_search_btn input{
     height: 34px;
    width: 450px;

    background: #EFEFEF;
    border:none;
 }
#float_search .header_search1 button{
    position: relative;
    left: -5px;
    top: -1px;
    height:34px;
    cursor:pointer;
    font-size: 15px;
    background-image:url(../../public/static/img/head/searchico.png);
    background-repeat: no-repeat;
    background-position: 28px 7px;

}
#float_search .header_search1 img {
    position: relative;
    top: 0px;
    left: 100px;
}
/*用户加载信息*/
.user_ico{
  width: 220px;
  position: absolute;
  height: 100px;
  left: 120px;
  color: #bb2a2a;
  top:29px;
  display: none;
  background: rgb(243, 243, 243);
  user-select: none;

}
.user_ico .font_money{
  position: relative;
  left:25px;
  font-size: 12px;
  color: #bb2a2a;
  
  top:25px;
}
.user_ico .font_info{
position: absolute;
left:60px;
top: 80px;
font-size: 2px !important;
color:#c28888;

}
.user_ico .user_img{
  width: 70px;
  position: relative;
  height: 70px;
  left: 10px;
  display: inline-block;
  top:10px;
  border-radius: 50%;
  background: #ec3e7d;
}
.user_ico img{
  border-radius: 50%;
}
.user_ico .font_vip{
  position: absolute;
  top:25px;
  left:95px;
}
#navbar:hover .user_ico{
 display:block;
}
.all_type{
    position:relative;
    left:0px;
}
.class_Contents{
    position: absolute;
    left: 194px;
    top:0px;
    background: #ffffff;
    width: 800px;
    height:auto;
	transition:.3s;
    display: none;
    box-shadow:2px 2px 1px 1px #d7c9d0;
    border: none;
}
.class_Contents a{
    color: #537d68;
    text-decoration: none;
    margin: 0px 10px 0px 14px;
    font-size: 13px;
    color:#150;
}
.class_Contents li{height:74px;}
.class_Contents li:last-child{height:80px;}
.class_Contents li a:nth-child(2){
    margin-left: 16px;
}

.class_Contents>div>ul>li>h6{
    margin-left: -410px !important;
    font-weight: bold;
}
.class_Contents>div>ul>li>h6:hover{
    color: #7d602f !important;
    cursor:pointer;
}
#t6s{
    position:relative;
    left:-100px;
}
.selfclass>div>div>ul{
    text-align: left !important;
}
.selfclass>div>div>ul>li>h6{
    margin: 0 !important;
}
.selfclass>div>div>ul>.border-0{
    padding:16px;
}
.attr_huli{
    left:0 !important;
}
#search_top{
    cursor: pointer;
}
</style>