<template>
    <div id="login_user_box">
     <div class="box">
         
         <div class="all_warp">
              <div class="left_item">
                    <img src="static/img/body/log_bg.png" alt="">
              </div>
             <!--body_left or body_right-->
          
                 <div class="right_item">
                        <h6>Login with your account</h6> 
                        <p class="is_user">if you do not have an account Sign Up</p>
                        <div class="general "    >   
                            <h5>LOGIN</h5>
                            
                            <i><img class="d-inline-block" src="static/img/head/passwico.png" alt=""/></i>
                            <i><img src="static/img/head/userico.png" alt=""/></i>
                            <div id="login_1" class="login_1">
                             <input name="user_phone" class="inut_1" placeholder="User name" type="text"/>
                                <input name="user_password" class="pass" placeholder="Password" type="password"/>
                           <div class="div_info">
                               <input class="div_itBG"  style="display:inline-block background=red" type="checkbox">    <span>Forgot Password?</span>
                           </div>
                                <button class="submit1">Login
                                </button>
                            </div>
                        </div>
                 </div>
             </div>
     </div>
     <!--底部-->
    </div>
</template>

<script>
    import '@/../public/static/js/share.js'
    import '@/../public/static/css/style.css'
    import '@/../public/static/css/login_user.css'
    import '@/../public/static/js/effect.js'
    import '@/../public/static/js/ajax.js'
    import '@/../public/static/js/userlogin.js'
    export default{
        data(){return{}},
        created(){
            
        }
    }
</script>

<style scoped>
#login_user_box{
    width:100%;
    height:100%;
    overflow:hidden;
}
</style>
