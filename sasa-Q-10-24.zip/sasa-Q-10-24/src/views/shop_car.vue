<template>
    <div class="box_car">
        <div class="box_car_title">
            <span>购物车</span>
        </div>
        <section class="cartMain">
	<div class="shopList_all">
        <div class="cartMain_hd">
		<ul class="order_lists cartTop">
			<li class="list_chk">
				<!--所有商品全选-->
				购物车
			</li>
			<li class="list_con">商品信息</li>
			<li class="list_info">商品参数</li>
			<li class="list_price">单价</li>
			<li class="list_amount">数量</li>
			<li class="list_sum">金额</li>
			<li class="list_op">操作</li>
		</ul>
	</div>

	<div class="cartBox">
		<div class="order_content">
			<ul class="order_lists" v-for="i in userShop" :id="i[0].sid">
				<li class="list_chk">

				</li>
				<li class="list_con">
					<div class="list_img"><a :href="'/shopping?sid='+i[0].sid"><img :src="url+i[0].img0" alt=""></a></div>
					<div class="list_text"><a href="'/shopping?sid='+i[0].sid"><b>{{i[0].brand}}</b>{{i[0].title}}</a></div>
				</li>
				<li class="list_info" >
					<p>规格：默认</p>
					<p>效果：{{i[0].effect}}</p>
					<p>产地(国家)：{{i[0].state}}</p>
				</li>
				<li class="list_price">
					<p class="price">￥{{i[0].price}}</p>
				</li>
				<li class="list_amount">
					<div class="amount_box">
						<a href="javascript:;" @click='count_bth(i[0].sid,-1)' class="reduce reSty">-</a>
						<input type="text" v-model="userShopcount[i[0].sid]" class="sum">
						<a href="javascript:;" @click='count_bth(i[0].sid,1)' class="plus">+</a>
					</div>
				</li>
				<li class="list_sum">
					<p class="sum_price">￥{{i[0].price*userShopcount[i[0].sid]}}</p>
				</li>
				<li class="list_op">
					<p class="del"><a href="javascript:;" @click="deleteShop(i[0].sid)" class="delBtn">移除商品</a></p>
				</li>
			</ul>
            <ul  class="cantShop">
                没有更多啦!.. 赶紧购物吧 ><a href="/Details">前往商城</a>&lt;
            </ul>
			
		</div>
	</div>

    </div>

	<!--底部-->
	<div class="bar-wrapper">
		<div class="bar-right">
			<div class="piece">已选商品<strong class="piece_num">{{zon_count}}</strong>件</div>
			<div class="totalMoney">共计: <strong class="total_text">{{zon_price}}.00</strong></div>
			<div class="calBtn"><a href="javascript:;">结算</a></div>
		</div>
	</div>
</section>
    </div>    
</template>

<script>
    export default{
        data(){ return {
            userShop:[],
            userShopcount:{},
            url:'http://127.0.0.1:4406/',
            uid:null,
            zon_count:0,
            zon_price:0
        } },
        methods:{
            getuserShop(){
                var id = document.cookie.split("%")[0]
                if(id==''){
                    alert("请登录....")
                    this.$router.push('/user_login')
                    this.$router.go(0)
                    }
                this.uid = id;
                (async function(self){
                    var res=await self.$http.get(`http://127.0.0.1:4406/user/getUserShop?uid=${id}`)
                    self.userShop=res.data.data
                    self.userShopcount = res.data.counts
                    self.zoncount()
                })(this)
                
            },
            count_bth(i,c){
                var el =$(`#${i} input[type='text']`).val()
                var val = parseInt(el) + c
                this.userShopcount[i]=val;

                if(val<=0){
                    this.deleteShop(i)
                    return;
                }
                this.updateCount(val,i)
                this.zoncount()
            },
            deleteShop(sid){
                if(confirm("确定清除商品？")){
                    (async function(self){
                        var res=await self.$http.get(`http://127.0.0.1:4406/user/delUserShop?uid=${self.uid}&sid=${sid}`)
                        $(`#${i}`).remove();
                    })(this)
                }else{
                    this.userShopcount[sid]=1
                }
            },
            updateCount(count,sid){
                var uid = this.uid;
                (async function(self){
                    var res=await self.$http.get(`http://127.0.0.1:4406/user/updateCount?uid=${uid}&sid=${sid}&count=${count}`)
                })(this)

            },
            zoncount(){
                this.zon_count = 0;
                this.zon_price = 0;
                var obj = this.userShopcount
                var objs = this.userShop
                var arr = []
               for(var key in obj) {
                   this.zon_count+= obj[key]
                   arr.push(obj[key])
               }
               for(var i=0;i<objs.length;i++){
                   this.zon_price += (parseFloat(objs[i][0].price)*parseFloat(arr[i]))
               }
            }
        },
        created(){
            this.getuserShop()
        },
        watch: {
           
        }
    }
</script>

<style scoped>
    .box_car{
        min-width: 1366px !important
    }
    .cantShop a{
        display: inline !important;
    }
    .cantShop{
        height: 70px;
        line-height: 70px;
    }
    .shopList_all{
        box-shadow: 0 0 3px #666
    }
    .box_car_title,.cantShop{
        text-align: center;
    }
    .box_car div:nth-child(1) span{
        font-size: 36px;

    }
        /* 清除内外边距 */

    body, h1, h2, h3, h4, h5, h6, hr, p, blockquote,
    /* structural elements 结构元素 */

    dl, dt, dd, ul, ol, li,
    /* list elements 列表元素 */

    pre,
    /* text formatting elements 文本格式元素 */

    fieldset, lengend, button, input, textarea,
    /* form elements 表单元素 */

    th, td {
        /* table elements 表格元素 */
        margin: 0;
        padding: 0;
    }
    /* 设置默认字体 */

    body, button, input, select, textarea {
        /* for ie */
        /*font: 12px/1 Tahoma, Helvetica, Arial, "宋体", sans-serif;*/
        font: 12px/1 Tahoma, Helvetica, Arial, "\5b8b\4f53", sans-serif;
        /* 用 ascii 字符表示，使得在任何编码下都无问题 */
    }

    h1 {
        font-size: 18px;
        /* 18px / 12px = 1.5 */
    }

    h2 {
        font-size: 16px;
    }

    h3 {
        font-size: 14px;
    }

    h4, h5, h6 {
        font-size: 100%;
    }

    address, cite, dfn, em, var {
        font-style: normal;
    }
    /* 将斜体扶正 */

    code, kbd, pre, samp, tt {
        font-family: "Courier New", Courier, monospace;
    }
    /* 统一等宽字体 */

    small {
        font-size: 12px;
    }
    /* 小于 12px 的中文很难阅读，让 small 正常化 */
    /* 重置列表元素 */

    ul, ol {
        list-style: none;
    }
    /* 重置文本格式元素 */

    a {
        text-decoration: none;
        color: #000;
    }
    /*a:hover { text-decoration: underline; }*/

    abbr[title], acronym[title] {
        /* 注：1.ie6 不支持 abbr; 2.这里用了属性选择符，ie6 下无效果 */
        border-bottom: 1px dotted;
        cursor: help;
    }

    q:before, q:after {
        content: '';
    }
    /* 重置表单元素 */

    legend {
        color: #000;
    }
    /* for ie6 */

    fieldset, img {
        border: none;
    }
    /* img 搭车：让链接里的 img 无边框 */
    /* 注：optgroup 无法扶正 */

    button, input, select, textarea {
        font-size: 100%;
        /* 使得表单元素在 ie 下能继承字体大小 */
    }
    /* 重置表格元素 */

    table {
        border-collapse: collapse;
        border-spacing: 0;
    }
    /* 重置 hr */

    hr {
        border: none;
        height: 1px;
    }
    /* 让非ie浏览器默认也显示垂直滚动条，防止因滚动条引起的闪烁 */

    html {
        overflow-y: scroll;
    }
    /*  浮动  */

    .fl {
        float: left
    }

    .fr {
        float: right
    }
    /*  清除浮动  */

    .clearfix:after {
        content: " ";
        display: block;
        clear: both;
        visibility: hidden;
    }





    html,body{
    position: relative;
    width: 100%;
    min-height: 950px;
}
input[type="checkbox"]{
    display: none;
}
label{
    position: relative;
    display: inline-block;
    z-index: 1;
    border: 1px solid #b8b8b8;
    margin-left: 10px;
    border-radius: 1px;
    width: 12px;
    height: 12px;
    cursor: pointer;
}
label.mark{
    background: url("../../public/static/img/ico/mark1.png") no-repeat -1px -1px;
}

a:hover{
    color: #ff873e;
    text-decoration: underline;
}



.cartMain{
    position: relative;
    width: 1200px;
    min-width: 1200px;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0px 0px 100px;
    min-height: 210px;
}
/*购物车头部*/
.cartMain_hd{
    width: 100%;
    height: 50px;
    line-height: 50px;
    color: #3c3c3c;
}
.cartMain_hd .cartTop{
    height: 50px;
}
.cartMain_hd .cartTop .list_chk{
    width: 80px;
    text-indent: 30px;
}
.cartMain_hd .cartTop .list_con{
    width: 312px;
}
.cartMain_hd .cartTop .list_chk label{
    position: absolute;
    left: 10px;
    top:19px;
    margin: 0;
}
.cartMain_hd .cartTop .list_info{
    padding: 0;
    text-indent: 15px;
}
.cartMain_hd .cartTop .list_con{
    text-indent: 140px;
}


.cartBox{
    width: 100%;
    margin-bottom: 15px;
}



/*商品列表*/
.cartBox .order_content{
    border: 1px solid #ccc;
}
.cartBox .order_content a{
    display: block;
}
.order_lists{
    width: 100%;
    height: 130px;
    border-bottom: 1px solid #e7e7e7;
}
.order_lists:last-child{
    border-bottom: none;
}
.order_lists li{
    float: left;
    height: 100%;
}

.order_lists .list_chk{
    position: relative;
    width: 50px;
}
.order_lists .list_chk input[type="checkbox"]{
    position: absolute;
    z-index: 0;
    left: -20px;
    top: -20px;
}
.order_lists .list_chk label{
    margin: 20px 0 0 24px;
}

.order_lists .list_con{
    width: 342px;
}
.order_lists .list_con .list_img{
    width: 90px;
    height: 90px;
    margin-top: 20px;
    float: left;
}
.order_lists .list_con .list_img img{
    width: 100%;
    vertical-align: top;
}
.order_lists .list_con .list_text{
    margin: 20px 0 0 10px;
    line-height: 18px;
    width: 200px;
    float: left;
}
.order_lists .list_con .list_text a{
    color: #3c3c3c;
}
.order_lists .list_con .list_text a:hover{
    color: #ff873e;
    text-decoration: underline;
}

.order_lists .list_info{
    width: 252px;
    box-sizing: border-box;
    padding: 20px 0;
}
.order_lists .list_info p{
    color: #9c9c9c;
    line-height: 18px;
    margin-left: 15px;
}
.order_lists .list_price{
    width: 130px;
}
.order_lists .list_price .price{
    margin-top: 20px;
    line-height: 18px;
    font-family: Verdana,Tahoma,arial;
    color: #3c3c3c;
    font-weight: bold;
}
.order_lists .list_amount{
    width: 120px;
}
.order_lists .list_amount .amount_box{
    margin-top: 20px;
    width: 77px;
    height: 25px;
    position: relative;
}
.order_lists .list_amount .amount_box input{
    width: 39px;
    height: 24px;
    line-height: 15px;
    border: 1px solid #aaa;
    color: #343434;
    text-align: center;
    padding: 4px 0;
    background-color: #fff;
    z-index: 2;
    position: absolute;
    left: 18px;
    float: left;
}
.order_lists .list_amount .amount_box a{
    float: left;
    height: 23px;
    width: 17px;
    border: 1px solid #e5e5e5;
    background: #f0f0f0;
    text-align: center;
    line-height: 23px;
    color: #444;
    position: absolute;
    top:0;
}
.order_lists .list_amount .amount_box a:hover{
    border-color: #ff873e;
    text-decoration: none;
    color: #ff873e;
    z-index: 3;
}

.order_lists .list_amount .amount_box .reduce{
    left: 0;
}

.order_lists .list_amount .amount_box .reSty{
    color: #cbcbcb;
    border-radius: 3px;
}
.order_lists .list_amount .amount_box .reSty:hover{
    border-right: none;
    border-color: #e5e5e5;
    text-decoration: none;
    color: #cbcbcb;
}

.order_lists .list_amount .amount_box .plus{
    border-left-color: transparent;
    right: 0;
    border-radius: 3px;
}


.order_lists .list_sum{
    width: 140px;
}
.order_lists .list_sum .sum_price{
    line-height: 18px;
    margin-top: 20px;
    font-family: Verdana,Tahoma,arial;
    color: #ff0000;
    font-weight: bold;
}
.order_lists .list_op{
    width: 164px;
}
.order_lists .list_op .del{
    margin-top: 20px;
    line-height: 18px;
}

/*底部总计算价*/
.bar-wrapper{
    width: 1200px;
    height: 50px;
    position: fixed;
    bottom: -1px;
    z-index: 99;
    background: #e5e5e5;
}
.bar-wrapper .bar-right{
    float: right;
    color: #3c3c3c;
}
.bar-wrapper .bar-right strong{
    color: #f40;
}

.bar-wrapper .bar-right .piece{
    float: left;
    min-width: 110px;
    margin-right: 20px;
    height: 50px;
    line-height: 50px;
}
.bar-wrapper .bar-right .piece .piece_num{
    display: inline-block;
    padding: 0 10px;
    font-weight: 700;
    font-size: 18px;
    font-family: tohoma,arial;
}
.bar-wrapper .bar-right .totalMoney{
    float: left;
    min-width: 100px;
    height: 50px;
    line-height: 50px;
}
.bar-wrapper .bar-right .totalMoney .total_text{
    float: right;
    font-weight: 400;
    font-size: 20px;
    font-family: Arial;
    vertical-align: middle;
    margin-right: 10px;
    margin-left: 15px;
}
.bar-wrapper .bar-right .calBtn{
    float: left;
}
.bar-wrapper .bar-right .calBtn a{
    display: block;
    width: 120px;
    height: 50px;
    color: #fff;
    background: #B0B0B0;
    cursor: not-allowed;
    font-size: 22px;
    letter-spacing: 5px;
    text-decoration: none;
    line-height: 50px;
    text-align: center;
    border-radius: 2px;
}
.bar-wrapper .bar-right .calBtn a.btn_sty{
    background: #f40;
    cursor: pointer;
}

/*自己定义的模态框*/
.model_bg{
    position: absolute;
    top:0;
    left: 0;
    bottom: 0;
    right: 0;
    background: rgba(0,0,0,.6);
    z-index: 999;
    display: none;
}
.my_model{
    position: fixed;
    display: none;
    top:50%;
    left: 50%;
    margin-top: -50px;
    margin-left: -200px;
    z-index: 9999;
    width: 360px;
    height: 145px;
    border: 1px solid #aeaeae;
    border-radius: 3px;
    padding: 20px;
    background: #fff;
}
.my_model .title{
    font-size: 14px;
    color: #3c3c3c;
    font-weight: 700;
    margin-bottom: 20px;
}
.my_model .title .closeModel{
    float: right;
    cursor: pointer;
}
.my_model p{
    line-height:16px;
}
.my_model .opBtn{
    margin-top: 20px;
}
.my_model .opBtn a{
    width: 58px;
    height: 28px;
    line-height: 28px;
    text-align: center;
    -webkit-border-radius: 1px;
    -moz-border-radius: 1px;
    -ms-border-radius: 1px;
    border-radius: 1px;
    display: inline-block;
    margin-right: 10px;
    font-weight: 700;
}
.my_model .dialog-sure{
    background: #52a0e5;
    color: #fff;
    border: 1px solid #52a0e5;
}

.my_model .dialog-close{
    background: #fff;
    border: 1px solid #d9d9d9;
    color: #3c3c3c;
}




</style>
