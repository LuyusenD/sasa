import Vue from 'vue'
import Router from 'vue-router'
import Home from './views/Home.vue'
import Index from './views/Index.vue'
import header from './views/header.vue'
import foot from './views/foot.vue'
import Member from './views/Member.vue'
import left_fixed from './components/index/left_fixed.vue'
import select1 from './components/index/select1.vue'
import Promo from './views/Promo.vue'
import shopping from './views/shopping.vue'
import register from './views/register.vue'
import user_login from './views/user_login.vue'
import details from './views/Details.vue'
import error from './views/404.vue'
import shop_car from './views/shop_car.vue'



Vue.use(Router)
 
export default new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    {path: '/',name: 'index', component: Index },
    {path: '/Member',name: 'index', component: Member },
    {path: '/Promo',name: 'index', component: Promo },
    {path: '/shopping',name: 'shopping',
      component: shopping
    },{
      path: '/details',
      name: 'details',
      component: details
    },{
      path: '/register',
      name: 'register',
      component: register
    },{
      path: '/user_login',
      name: 'user_login',
      component: user_login
    },{
      path: '/404',
      name: 'error',
      component: error
    },{
      path: '/shop_car',
      name: 'shop_car',
      component: shop_car
    }
  ]
})
