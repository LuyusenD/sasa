<template>
<div style="height:420px">
  <div class="carouselsx" >
       <ul>
          <li class="active"></li>
          <li v-for="s in 4"></li>
       </ul>
       <div class="list_img">
       <a v-for="i in carouselsxs" :href="i.href" :title="i.title">
       <img :src="i.img"/>
       </a>
       </div>
  </div>
</div>
</template>

<script>
export default {
  name: 'carouselsx',
  data(){  return {carouselsxs :[] } },
  methods:{
      getimgae(){
         (async function(self){
         var res=await self.$http.get("http://127.0.0.1:4406/index/",{
         })
          self.carouselsxs=res.data;
         })(this)
      }
  },created(){
   this.getimgae()
  }
}
 
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->

<style scoped>


</style>
