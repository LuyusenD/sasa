<template>

    <div>
        <div class="section_1">
        <!--内容1 图-->
        <ul class="list-unstyled d-flex justify-content-between w-100">
            <li><a href="#"><img src="static/img/body/promo2a-02.jpg"/></a></li>
            <li><a href="#"><img src="static/img/body/promo2b-16.jpg"/></a></li>
            <li><a href="#"><img src="static/img/body/promo2c-06.jpg"/></a></li>
        </ul>
        <!--内容1 文-->
        <ul class="list-unstyled d-flex section_1_ul2 mt-4 justify-content-between" id="l1_foot__">
            <li>
                <img src="static/img/body/1.png"/>
                <span>
                    <h6>香港特快直送 <br/><h6 class="small text-muted">包税零扣关 ¥288免邮</h6></h6>
                </span>
            </li>
            <li>
                <img src="static/img/body/2.png"/>
                <span>
                    <h6 class="pl-1">正品保证 <br/><h6 class="small text-muted pl-1">专注美妆护肤40年</h6></h6>
                </span>
            </li>
            <li>
                <img src="static/img/body/3.png"/>
                <span>
                    <h6 class="pl-2">保税仓直送 <br/><h6 class="small text-muted pl-2">包税零扣关 ¥168免邮</h6></h6>
                </span>
            </li>
            <li>
                <img src="static/img/body/4.png"/>
                <span>
                    <h6 class="pl-2">30天退换保证 <br/><h6 class="small text-muted pl-2">为您提供售后无忧保障</h6></h6>
                </span>
            </li>
            <li>
                <img src="static/img/body/5.png"/>
                <span>
                    <h6 class="pl-1">香港上市 <br/><h6 class="small text-muted pl-1">股票代码 HK00178</h6></h6>
                </span>
            </li>
        </ul>
    </div>
    </div>

</template>
<script>
    export default{
        name:"",
        data(){
            return{}
        }
    }
</script>
<style scoped>
#l1_foot__>li>span>h6{
    display:block;
}

</style>