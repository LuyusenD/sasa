<template>
   <div>
        <div class="section_2 mt-4" title="每日必看">
        <img src="static/img/body/must_check.png"/>
        <div id="f1" 
        class="d-flex foolr  flex-wrap justify-content-between mt-4">
        <div v-for="i in daylook" class="d-flex"><div>
              <img :src="i.img">
        </div>
        <div 
        class="d-flex justify-content-center flex-column align-items-center section_2_1 ">
        <h5>
        <a :href="url+i.did">{{i.title}}</a>
        </h5>
        <h6>
        <a :href="url+i.did">{{i.stitle}}</a>
        </h6>
        <h6 class="small">
        <a :href="url+i.did">{{i.price}}</a>
        </h6>
        <a :href="url+i.did" class="section_a_linear_z">立即疯抢</a>
		</div>
        </div>
        </div>
        </div>
    </div>
   </div>
</template>

<script>
    export default {
        name:"daylook",
        data(){
            return {
                daylook:[],
                url:'shopping?sid='
            }
        },
        methods:{
            getdaylook(){
              (async function(self){
         var res=await self.$http.get("http://127.0.0.1:4406/index/DayLook",{
               })
               self.daylook=res.data;
               })(this)
            }
        },created() {
          this.getdaylook();
            
        }
    } 
</script>