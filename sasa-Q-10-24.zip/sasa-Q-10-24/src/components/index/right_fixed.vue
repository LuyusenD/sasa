<template>
<div> 

    
<div class="r-fiexd">
    <div class="r-fiexd-1">
        <div>
            <div><a href="/Member"><img src="static/img/head/1.png" class="r-fiexd-img"/></a></div>
            <a href="/Member" class="r_opacity">我的账户 <span class="r_opacity_img"><img src="static/img/head/sjx.png"/></span></a>
        </div>
        <div class="mt-2 r-fiexd-1-2" @click="toShop()">
            <div class="mt-3"><img src="static/img/head/2.png" alt=""/></div>
            <span class="d-flex flex-wrap"><a >购物车</a></span>
            <b class="badge-pill small ml-2 m-0">★</b>
        </div>
        <div class="mt-3">
            <div><a href="/Member"><img src="static/img/head/3.png" class="r-fiexd-img"/></a></div>
            <a href="/Member" class="r_opacity">我的收藏 <span class="r_opacity_img"><img src="static/img/head/sjx.png"/></span></a>
        </div>
        <div class="mt-1">
            <div> <a href="#"><img src="static/img/head/4.png" class="r-fiexd-img"/></a></div>
            <a href="#" class="r_opacity">浏览记录 <span class="r_opacity_img"><img src="static/img/head/sjx.png"/></span></a>
        </div>
    </div>
    <div class="r-fiexd-2">
        <div>
            <div><a href="#"><img src="static/img/head/5.png" class="r-fiexd-img"/></a></div>
            <a href="#" class="r_opacity">线上客服 <span class="r_opacity_img"><img src="static/img/head/sjx.png"/></span></a>
        </div>
        <div>
            <div> <a href="#"><img src="static/img/head/6.png" class="r-fiexd-img"/></a></div>
            <a href="#" id="gfewm" class="r_opacity"><img src="static/img/body/gfewm.jpg" /><span id="gfewm_img" class="r_opacity_img"><img src="static/img/head/sjx1.png"/></span></a>
        </div>
        <div class="mt-3" id="Top">
            <div>
                <a href="#" onclick="fun()"  class="d-flex flex-column text-center"><span style="color:#c69a62">▲</span><span class="text-white">Top</span></a>
            </div>
        </div>
    </div>
</div>
</div> 
</template>
          
<script>
    export default{
        name:"rightFixed",
        created(){

        },
        data(){
            return{}
        },
        methods:{
            toShop(){
                this.$router.push('/shop_car')
                this.$router.go(0)
            }
        }
    }
</script>
<style >

</style>