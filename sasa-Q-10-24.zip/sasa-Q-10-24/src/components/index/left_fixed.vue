<template>
<div>
  <div class="left_floor">
        <ul>
             <li class="lift_item ">
            <span></span><a href="javascript:;">必看</a>
            </li>
            <li class="lift_item">
            <a href="javascript:;"><span></span>特卖</a>
            </li>
            <li class="lift_item">
            <a href="javascript:;"><span></span>排行榜</a>
            </li>
            <li class="lift_item">
            <a href="javascript:;"><span></span>新品</a>
            </li>
        </ul>
    </div>
</div>
</template>

<script>
    export default{
        
    }
</script>

<style lang="">
    
</style>