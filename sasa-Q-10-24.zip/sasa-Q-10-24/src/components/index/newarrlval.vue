<template>
  <div>
    <div class="section_5 mt-5">
        <img src="static/img/body/new_arrival.png"/>
        <div id="f3" class="d-flex justify-content-between  mt-4 flex-wrap foolr">
            <div v-for="item in newarrlval"  class="f3_item">
                <span>新品上市</span>
                <img class="w-100 f3_img1"  :src="item.img"/>
                <div class="section_4_2">
                    <span><img src="static/img/body/section5_rb.png" class="w-25"/> {{item.origin_name}}</span>
                    <a href="#" class="f3_font2"><b class="b">{{item.delivery}}</b>{{item.title}}</a>
                    <div class="d-flex align-items-baseline justify-content-between mt-3">
                        <div class="f3_font3"><span>￥</span><span class="f3_font4">{{item.price}}</span> <s class="small"> </s></div>
                    </div>
                </div>
                <div class="bot_Zez"></div>
            </div>
  
            </div>
 
        </div>
    
	    <br/>
    </div>
</template>


<script>
export default {
  name: 'newarrlval',
  data(){  return {newarrlval:[]} },
  methods:{
      getlimite(){
         (async function(self){
         var res=await self.$http.get("http://127.0.0.1:4406/index/NewArrival",{})
          self.newarrlval=res.data;
         })(this)

      }
  },created(){
     this.getlimite()
  }
}
</script>