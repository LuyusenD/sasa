<template>
 <div>
    <div class="section_3 mt-5p" title="疯抢特卖">
        <img src="static/img/body/limitted_offer.png" class="mt-5"><h5 class="text-center mt-2">每天9:00准时点开抢</h5>
        <div class="d-flex flex-wrap foolr justify-content-between mb-4">
       
            <div v-for="item in limite" class="d-flex"><div class="col-7 p-0">
                    <a :href="item.href"><img :src="item.img"></a>
                    <b class="section_3_discont">
                        {{item.discount}}<span class="small">折</span>
                   </b>
              </div>
              <div class="col-6 section3_2 pl-5">
                    <div class="section_3_data">剩余 23 : 24 : 29</div>
                    <div><img src="static/img/body/shuangy.png">{{item.title}}</div>
                    <div><b class="b">澳门特快直送 零扣关</b>{{item.stitle}}</div>
                    <div><span>￥</span><span>1098</span> <s class="small">￥ {{item.price}}</s></div>
                    <div>
                        <div>已售 <span>{{item.sell}}</span>件</div>
                        <a :href="item.href" class="section_a_linear_z">马上抢购</a>
                    </div>
              </div>
             </div>
        </div>
        <div class="text-center">
            <a href="#" class="section_a_linear_z">查看更多特卖▼</a>
        </div>
    </div>
 </div>
</template>
<script>
    

export default {
  name: 'limitedoffer',
  data(){  return {limite:[],url:'shopping?sid='} },
  methods:{
      getlimite(){
         (async function(self){
         var res=await self.$http.get("http://127.0.0.1:4406/index/Limited",{})
          self.limite=res.data;
         })(this)

      }
  },created(){
     this.getlimite()
  }
}
 </script>