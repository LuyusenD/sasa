<template>
  <div>
        <div class="section_4 mt-5" title="排行榜">
        <img src="static/img/body/title_ranking.png"/>
        <div id="f2"  class="d-flex foolr justify-content-between mt-4">
            <div class="section__4">
                <div class="col-12 section_4_1">护肤排行榜</div>
                <div v-for="item in ranking.slice(0,5)" class="row">
					<div class="col-3 ml-3">
						<span class="one"></span>
						<a href="${href}"><img :src="item.img" class="w-100"/></a>
					</div>
					<div class="col-8 section_4_2">
						<a href="${href}"><b class="b">{{item.delivery}}</b>{{item.title}}</a>
						<div class="d-flex align-items-baseline justify-content-between">
							<div><span>￥</span><span>{{item.price}} </span> <s class="small"> {{item.yprice}}</s></div>
							<div><div class="text-muted font_8">已售 <span>{{item.sell}}</span></div></div>
						</div>
					</div>
				</div>	
            </div>
            <div class="section__4">
                <div class="col-12 section_4_1">彩妆排行榜</div>
                 <div v-for="item in ranking.slice(5,10)" class="row">
					<div class="col-3 ml-3">
						<span class="one"></span>
						<a href="${href}"><img :src="item.img" class="w-100"/></a>
					</div>
					<div class="col-8 section_4_2">
						<a href="${href}"><b class="b">{{item.delivery}}</b>{{item.title}}</a>
						<div class="d-flex align-items-baseline justify-content-between">
							<div><span>￥</span><span>{{item.price}} </span> <s class="small"> {{item.yprice}}</s></div>
							<div><div class="text-muted font_8">已售 <span>{{item.sell}}</span></div></div>
						</div>
					</div>
				</div>	
            </div>
            <div class="section__4">
                <div class="col-12 section_4_1">个护排行榜</div>
                    <div v-for="item in ranking.slice(10,15)" class="row">
					<div class="col-3 ml-3">
						<span class="one"></span>
						<a href="${href}"><img :src="item.img" class="w-100"/></a>
					</div>
					<div class="col-8 section_4_2">
						<a href="${href}"><b class="b">{{item.delivery}}</b>{{item.title}}</a>
						<div class="d-flex align-items-baseline justify-content-between">
							<div><span>￥</span><span>{{item.price}} </span> <s class="small"> {{item.yprice}}</s></div>
							<div><div class="text-muted font_8">已售 <span>320</span></div></div>
						</div>
					</div>
				</div>
            </div>
        </div>
    </div>
  </div>
</template>
<script>

export default {
  name: 'ranking',
  data(){  return {ranking:[],sell:{}} },
  methods:{
      getlimite(){
         (async function(self){
         var res=await self.$http.get("http://127.0.0.1:4406/index/Ranking",{})
          self.ranking=res.data;
         })(this)

      }
  },created(){
     this.getlimite()
  }
}

</script>