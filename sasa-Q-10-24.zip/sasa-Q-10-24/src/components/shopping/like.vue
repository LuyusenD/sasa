<template>
    <div class="section_2" id="section_2">
        <span>猜你喜欢</span>
        <div class="s2_list d-flex justify-content-around">
            <div v-for="i in res"><a href="#"><img :src="i.img0"/></a> <a href="#">Yves Saint Laurent 纯口红 3.8 克</a> <p>￥317.00 </p></div>
            <!--<div><a href="#"><img src="static/img/body/Shopping_s2_list_2.jpg"/></a> <a href="#">Yves Saint Laurent 纯口红 3.8 克</a> <p>￥317.00 </p></div>
            <div><a href="#"><img src="static/img/body/Shopping_s2_list_3.jpg"/></a> <a href="#">Yves Saint Laurent 纯口红 3.8 克</a> <p>￥317.00 </p></div>
            <div><a href="#"><img src="static/img/body/Shopping_s2_list_4.jpg"/></a> <a href="#">Yves Saint Laurent 纯口红 3.8 克</a> <p>￥317.00 </p></div>
            <div><a href="#"><img src="static/img/body/Shopping_s2_list_5.jpg"/></a> <a href="#">Yves Saint Laurent 纯口红 3.8 克</a> <p>￥317.00 </p></div> -->
        </div>
    </div>
</template>

<script>
    export default{
        data(){return {res:[]}},
        created(){
            this.getres()
        },
        methods:{
            getres(){
                (async function(self){
                    var res=await self.$http.get("http://127.0.0.1:4406/shopping/like")
                    res=res.data
                    let shop_count=parseInt(Math.random()*50);
                    self.res=res.slice(shop_count,shop_count+5)
                })(this)
            }
        }
    }
</script>

<style scoped>
.section_2 {
  padding-left: 76px;
  padding-right: 90px;
  margin-top: 16px; }
.section_2 {
  margin-top: 40px; }
  .section_2 span {
    font-weight: 600;
    font-size: 1.5em; }
  .section_2 .s2_list {
    margin: 0 -20px; }
    .section_2 .s2_list div {
      margin: 6px;
      background: #fff;
      width: 232px;
      height: 330px;
      padding: 15px; }
      .section_2 .s2_list div a {
        display: block;
        text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
        color: #000; }
        .section_2 .s2_list div a img {
          width: 100%;
          transition: .5s; }
          .section_2 .s2_list div a img:hover {
            opacity: .6; }
        .section_2 .s2_list div a:hover {
          text-decoration: none; }
      .section_2 .s2_list div p {
        font-size: 1.6em;
        color: #EC3E7C;
        margin-top: 10px; }
</style>