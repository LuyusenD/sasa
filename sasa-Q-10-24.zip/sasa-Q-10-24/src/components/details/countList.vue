<template id="countList">
    <div class="nav_foot mt-4">
        <ul class="list-unstyled">
            <a href="#" class="nav_foot_prev" @click.prevent="shoplistpno('上一页')">上一页</a>
            <a v-for="i in Math.ceil(shops.length/6)" href="#d" class="nav_foot_a" @click.prevent="shoplistpno(i)">{{i}}</a><!-- @click="count_i(i)"-->
            <a href="#" class="nav_foot_next" @click.prevent="shoplistpno('下一页')">下一页</a>
        </ul>
    </div>
</template>

<script>
    export default{
        data(){return {}},
        props:["shops","pno","data"],
        methods:{
            shoplistpno(vals){
                var i=6,
                    prev=$(".nav_foot>ul>a:first()"),
                    counts=parseInt($('.nav_foot_active').html());
                $('.nav_foot_active').removeClass("nav_foot_active");

                if(vals=='上一页'){
                    this.$parent.getshoplist(i*(counts-2),counts-2,this.data);
                }else if(vals=='下一页'){
                    this.$parent.getshoplist(i*(counts),counts,this.data);
                }else{
                
                    this.$parent.getshoplist(i*(vals-1),vals-1,this.data);
                }
                $("html,body").animate({scrollTop:595},0)


            }
        }
    }
</script>