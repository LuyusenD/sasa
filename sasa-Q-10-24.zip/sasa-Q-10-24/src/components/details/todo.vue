<template id="todo">
    <div class="d-flex flex-wrap">
        <div v-for="i in p" class="shop_active">
            <todo-list :i="i"></todo-list>
        </div> 
        <count-list :shops="shops" :pno="pno" :data="data"></count-list>
    </div>
</template>


<script>
    import todoList from '@/components/details/todoList.vue'
    import countList from '@/components/details/countList.vue'
    import axios from 'axios'
    export default{
        data(){return {shops:[],p:0,index:0,pno:0,data:''}},
        components:{todoList,countList},
        created(){
            var i = sessionStorage['details'];
            if(i!==undefined){
                this.getshoplist(0,0,i)
            }
        
        },
        updated() {
        this.active()   
        },
        methods:{
        getshoplist(index=0,pno=0,data=''){
            (async function(self){
                var res=await axios.get("http://127.0.0.1:4406/shopping/details?data="+data)
                self.shops=res.data;
                self.p=res.data.slice(index,index+6)
                self.index=index
                self.pno=pno
                self.data=data
                let count= Math.ceil(res.data.length/6);
                    if(pno==0)$(".nav_foot_prev").addClass("disabled");else $(".nav_foot_prev").removeClass("disabled");
                    if(pno==count-1)$('.nav_foot_next').addClass("disabled");else $('.nav_foot_next').removeClass("disabled");
                })(this,index,pno,data)
            },
            active(){
                var pno=this.pno
                $('.nav_foot_a').each(function(){
                    if($(this).html()==pno+1){
                        $(this).addClass("nav_foot_active")
                    }
                })
            },
            updateList(vals){
                if(vals=='面部保养'){
                    this.getshoplist(0,0,1)
                }else if(vals=='彩妆'){
                    this.getshoplist(0,0,2)
                }else if(vals=='香水'){
                    this.getshoplist(0,0,3)
                }else if(vals=='健康'){
                    this.getshoplist(0,0,4)
                }else if(vals=='个人护理'){
                    this.getshoplist(0,0,5)
                }else if(vals=='男人专区'){
                    this.getshoplist(0,0,6)
                }else if(vals=='婴儿护理专区'){
                    this.getshoplist(0,0,7)
                }else if(vals=='显示所有商品'){
                    this.getshoplist(0,0,'')
                }
            }

        },
        created(){
            this.getshoplist(0,0,'')
        }
    }
</script>

<style scoped>

</style>
