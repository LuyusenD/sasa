<template id="todoList">
        <div class="search_3_content ">
                <div class="s3_content">
                        <div class="s3_item">
                            <div class="s3_item_1"><a :href="'/shopping?sid='+`${i.sid}`"><img :src="i.img0"/></a></div>
                            <div class="s3_item_2 list-unstyled float-right">
                                <li><img :src="i.img0"/></li>
                                <li><img :src="i.img1"/></li>
                                <li><img :src="i.img2"/></li>
                            </div>
                            <div class="s3_item_3">
                                <span class="text_F63D81 my_font_15r">￥{{i.price}}.0 <s class="text-secondary small"> {{i.yprice}}</s></span>
                                <span class="text_C69A62">{{i.discount}}折</span>
                            </div>
                            <div class="s3_item_4">
                                <span><b>香港特快直送 零扣关</b></span>
                                <p><b>{{i.brand}}</b></p>
                                <p class="my_font_9r"><a href="#" class="nav-link p-0">{{i.title}}</a></p>
                                <p class="mt-4"></p>
                            </div>
                            <div class="s3_item_5">
                                <a :href="'/shopping?sid='+`${i.sid}`">加入购物车</a>
                            </div>
                        </div>
                </div>
            </div>
</template>

<script>
    export default{
        data(){return{}},
        methods:{},
        created(){},
        props:["i"],
    }
</script>