$(function(){
    /*setInterval(function(){
        let val=$(".r-fixed-shop").find("li").length;
    $(".r-fiexd-1-2 b").html(val);
    $(".r-content-submit .shop_count").html(val);
    var vals=0;
    $(".shop_price").each(function(){
        vals+=parseFloat($(this).html())
    })
    $(".shop_prices").html(vals.toFixed(2));
    },200)*/
})