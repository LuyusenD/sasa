/**
 * Created by web on 2018/9/1.
 */
$(function(){
    /*btn hover */
    $('.look_btn_b a').mouseover(function(){$(this).siblings('div').animate({left:"0px"})});
    $('.look_btn_b a').mouseout(function(){$(this).siblings('div').animate({left:"-150px"})});
    /*search3 nav animate*/
    (()=>{
        var i=0;
        $(".s3_opacity_li").click(()=>{
            i++;
            if(i%2==1){
                $('.s3_opacity').css("background", "#fff");
                $('.s3_opacity_img').addClass('s3_opacity_rotate');
                $('.s3_opacity_list').stop(true).slideDown()
            }else {
                $('.s3_opacity').css("background","#E8E6E7");
                $('.s3_opacity_img').removeClass('s3_opacity_rotate');
                $('.s3_opacity_list').stop(true).slideUp()
            }
        })
    })()
    /*search3 nav opacity*/
    $(window).scroll(()=>{
        var top= $("html,body").scrollTop();
        if(top>2390&&top<4300){$('.search_3_nav').css({"position":"fixed","top":"10px","z-index":"100","width":"250px"})}else{
            {$('.search_3_nav').css({"position":"relative","top":"0px"})}
        }

    })

    $('.s3_item_2 li').mouseover(function(){
        var src=$(this).find('img').attr("src");
        $(this).parent().prev().find('a img').attr("src",src);
    })
    $('.s3_content').mouseover(function(){
        $(this).addClass("Details_list");
        $(this).find(".s3_item_2").stop(true).show(300);
        $(this).find(".s3_item_5 a").css("display","block");
    })
    $('.s3_content').mouseout(function(){
        $(this).removeClass("Details_list");
        $(this).find(".s3_item_2").stop(true).hide(300);
        $(this).find(".s3_item_5 a").css("display","none");
    })


})




