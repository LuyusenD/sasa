/*加载头部资料信息*/
/*
function isuser(money,ico){
var span=document.querySelector(
    ".navbar .navbar-brand"
)
var u_cookie=decodeURI(document.cookie).split("|");
var html=`
    欢迎光临莎莎网！&nbsp;&nbsp;&nbsp;
        <a href="Member.html">${u_cookie[1]}</a>&nbsp;&nbsp;&nbsp;
        或
        &nbsp;&nbsp;<a  href="register.html">退出</a>
    <div class="user_ico"><div class="user_img"><img src="${ico}"></div><span class="font_money">余额:&nbsp;&nbsp;&nbsp;¥${money.toFixed(2)}</span><span class="font_vip">级别：普通会员</span><span class="font_info">莎莎祝你，每天生活愉快。</span></div>`;
 span.innerHTML=html;
}
/*复选框样式*/
function checkico(elem,bg="duiico"){
    elem.click(function(){
      elem.toggleClass(bg)
    /*使用默认要引入默认的class，加入背景图bg*/
  }
)};
/*正则信息提示框 e_rr错误信息 n_不能为空*/
function info({elem,top,left,e_rr,n_ull,phme,reg}){
    var input=elem,T=input.offset().top,L=input.offset().left; 
    var sj=Math.ceil(Math.random()*30);
    var cla2="cls"+sj
    var Err=$(`<div class="Err">${e_rr}</div>`);
    var notNUll=$(`<div class="notNUll ${cla2}">${n_ull}</div>`);
    input.focus(function(){
       $(`.${cla2}`).remove();
      $("body").append(Err);
       Err.offset({left:L+left,top:T+top})
       Err.animate({
            top:T-10,
            opacity:.7
       },300)
      }
    );
    input.blur(function(){
     if(phme!==undefined){
      var phone_Reg = /^1[3-8]\d{9}$/;
      var meail_Reg = /(.*@.*?)\.(com|cn|net)(\.cn)?/;
      var inut_1=input.val();
     if(phone_Reg.test(inut_1)||meail_Reg.test(inut_1)){
      input.addClass("Border")
          $(".Err").remove();
         }else if(inut_1==''){
          $(".Err").remove();
          $("body").append(notNUll);
          notNUll.offset({left:L+left,top:T-top});
          notNUll.animate({
            top:T-6,
            opacity:.7
       },400)
         }
        }
        if(reg!==undefined){
          if(reg.test(input.val())){
          input.addClass("Border")
          $(".Err").remove();
         }else if(input.val()==''){
          $(".Err").remove();
          $("body").append(notNUll);
          notNUll.offset({left:L+left,top:T-top});
          notNUll.animate({
            top:T-6,
            opacity:.7
       },400)}
        }
      })
    }

/*top提示条 class可自定义*/
function inof(elem,txt,clas=".top_info"){
    var box=$(`<div class="top_info">
    ${txt}
    </div>`)
    $("body").append(box)
    $(".top_info").stop()
    .animate({top:0+"%"},800)
    .animate({top:0+"%"},900)
    .animate({ top:-10+"%"},1400,function(){  $(".top_info").remove()});
  };

/*输入框 placeholder文本左移*/
function plays(elem,left){
    var L=elem.offset().left;
    var T=elem.offset().top;
    var box=$(`<span class="inp_span1"></span>`);
    box.offset({left:L,top:T+5})
  $('body').append(box);
    box.html(elem.attr('placeholder'));
    elem.attr('placeholder',"");
   box.css("display","block")
      box.stop().animate({
        left:L-left,
        top:T+5
      },200)
}

