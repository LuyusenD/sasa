/**
 * Created by web on 2018/9/1.
 */
$(function(){
    /*¥��Ч��*/
    var $list=$(".left_floor");
    if($("#f1")[0]!=undefined){
        $(window).scroll(function(){
            var $f1=$("#f1");
            var scrollTop=$("html,body").scrollTop();
            var offsetscroll=$f1.offset().top;
            if(offsetscroll<scrollTop+innerHeight/2){
                $list.fadeIn(500)
            }else{
                $list.fadeOut(700)
            }
            var floor=$(".foolr")
            floor.each(function(i,elem){
                var $f=$(elem);
                if($f.offset().top<scrollTop+innerHeight/2){
                    $list.find(".lift_item:eq("+i+")").addClass("lift_hove").siblings().removeClass("lift_hove");
                }

            })
        })
    }
    /*��������this¥��*/
    $list.children("ul").on("click","li",function(){
        var $li=$(this);
        var  i=$li.index();
        var $fl=$(".foolr:eq("+i+")").offset().top;
        $("html").animate({
            scrollTop:$fl-140
        },500)
    })

    var $float_search=$("#float_search");
        if($(".section_5")[0]!==undefined){
        $(window).scroll(function(){
            var section_5=$(".section_5").offset().top;
            var scroll=$("body,html").scrollTop();
            if(scroll>450&&scroll<section_5-300){
                $float_search.fadeIn(800);
            }else{
                $float_search.fadeOut(400);
            }
        })
    }
})

/*index setintaival 9:00 section3 ？*/
    setInterval(function(){let now=new Date();
        $data=$(".section3_2>.section_3_data")
        let sss=new Date(`${now.getFullYear()}/${now.getMonth()+1}/${now.getDate()+1} 9:00:00`);
        let s=parseInt((sss-now)/1000);
        let h=parseInt(s%(3600*24)/3600);
        if(h<10) h="0"+h;
        let m=parseInt(s%3600/60);
        if(m<10) m="0"+m;
        s%=60;
        if(s<10) s="0"+s;
        var val=`剩余 ${h} : ${m} : ${s}`;
       $data.html(val);
    },1000)