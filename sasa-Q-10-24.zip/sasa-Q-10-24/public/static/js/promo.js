$(function() {
    setTimeout(function(){
        $('.s3_item_2 li').mouseover(function(){
            var src=$(this).find('img').attr("src");
            $(this).parent().prev().find('a img').attr("src",src);
        })
        $('.s3_content').mouseover(function(){
            $(this).addClass("sss");
            $(this).find(".s3_item_2").stop(true).show(300);
            $(this).find(".s3_item_5 a").css("display","block");
        })
        $('.s3_content').mouseout(function(){
            $(this).removeClass("sss");
            $(this).find(".s3_item_2").stop(true).hide(300);
            $(this).find(".s3_item_5 a").css("display","none");
        })
    },1000)
  
})