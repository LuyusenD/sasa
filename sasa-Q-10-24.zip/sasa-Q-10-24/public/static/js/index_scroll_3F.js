$(function(){
    $(function(){
        var f3=$("#f3"),box_zhezao=$(".box_zhezao");
        var y,x,top,left,H,W,html,canMove=false;
        var btm_Ckou=$(".btm_Ckou");
	if(btm_Ckou[0]!==undefined){
        var btmTop=btm_Ckou.offset().top;
        var isture=false,isthis,isture1;
        f3.find(".f3_item").mousedown(function(){
           canMove=true;  isture=false;  isthis=$(this);
           isture1=true;
           html=`<div class="float_div bot_shop">`
           +$(this).html()+`</div>`;
           $(".btm_Ckou ").after(html);
           top=$(".float_div").offset().top;
           left=$(".float_div").offset().left;
           H=$(".float_div").height()/2;
           W=$(".float_div").width()/2;
           btm_Ckou.stop().animate({bottom:0+'%'},500);
       })
       $(window).mousemove(function(e){
           if(canMove){
           y=e.pageY,x=e.pageX;
           isthis.addClass("f3_itemyc");
           $(".float_div").offset({top:y-H, left:x-W});
           var float_dT=$(".float_div").offset().top;
           box_zhezao.fadeIn();
           $(".float_div").mouseup(function(){
               canMove=false;
               isture1=false;
               if(btmTop<float_dT+400){
                   isture=true;
                   $(".float_div").remove();
                   isture1=true;
               }
               isthis.removeClass("f3_itemyc")
               $(".float_div").remove();
               box_zhezao.fadeOut();
           })
       }
       if(isture){
           isture=false;
           var divchild=`<div class="btm_d1"><div class="bot_shop">`+isthis.html()+`</div></div>`;
               btm_Ckou.append(divchild);
               box_zhezao.fadeOut(300);
       }
       if(isture1){
           btm_Ckou.mouseleave(function(){
           btm_Ckou.stop().animate({bottom:-0+'%'},900);
               isture1=false;
           })
       }else{
           var bt=btm_Ckou.offset().top.toFixed(0); 
            btm_Ckou.stop().animate({bottom:-40+'%'},900);
            isture1=true;
       }
       })
	}
   })
   
})