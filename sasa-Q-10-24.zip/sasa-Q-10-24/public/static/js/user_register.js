$(function(){
    $(".text").focus(function(){ /*获取焦点调用函数*/
        var go= $(this).siblings("div").find("div"); /*获取右边div*/
        go.removeClass("user_x_g tel_x_g info_x_g pwd_x_g cpwd_x_b cpwd_x_g user_x_k pwd_x_k pwd_z_1 pwd_z user_x_c");/*每次的获取焦点,清除该文本框右方的样式*/
        $(this).removeClass("border_r");/*清除红色边框*/
        $(this).siblings("span").animate({left: '140px'}); /*将手机号码/用户名 span 左移到外部*/
        $(this).siblings("div").find("i").css({"background":"url(static/zsjx.png)","width":"16px","height":"16px"});/*在右元素中的i 插入灰色三角*/
        var text= $(this).siblings('span').text();/*获取span内容 用于判断*/
        text== '用户名'?go.addClass("alert_r_1 user_"):text== '手机号'?go.addClass("alert_r_1 tel_"):text== '验证码'?go.addClass("alert_r_1 info_"):text== '设置密码'?go.addClass("alert_r_1 pwd_"):text== '确认密码'?go.addClass("alert_r_1 cpwd_"):'';/*判断 是哪一个被获取焦点 右边就会添加相对class*/
    })
    $("span").click(function(){
        $(this).siblings('input').focus()
    })
    $(".text").blur(function(){
        var text= $(this).siblings('span').text();   /*获取span内容*/
        var go= $(this).siblings("div").find("div");  /*获取右边变动div */
        if(text=='用户名'){
            var arr= $(this).val().match(/^[\u4e00-\u9fa50-9A-Za-z]{4,20}$/); /*正则表达式对input 检测*/
            if($(this).val()!=""){/*检查输入框内容是否为空*/
                if(arr!=null){ /*判断正则表达式是否正确  正确执行*/
                    $(this).siblings("div").find("i").css({"background":"url(static/yes.png)","width":"32px","height":"32px"});/*正确图标*/
                    go.removeClass("user_x_c alert_r_1 user_");/*清除class*/
                }else{
                    $(this).siblings("div").find("i").css({"background":"url(static/zsjx1.png)","width":"16px","height":"16px"});/*黄色小三角*/
                    $(this).addClass("border_r");/*添加红色边框class*/
                    go.removeClass("user_ user_x_c");/*清除class*/
                    go.addClass("user_x_g");/*更换class内容*/
                }
            }else{
                $(this).siblings("div").find("i").css({"background":"url(static/zsjx1.png)","width":"16px","height":"16px"});
                $(this).addClass("border_r");
                go.removeClass("user_ user_x_g user_x_c");
                go.addClass("user_x_k");
            }
        }else if(text=='手机号'){
            var arr= $(this).val().match(/1[3-8]\d{9}/); /*正则表达式对input 检测*/
            if(arr!=null){
                $(this).siblings("div").find("i").css({"background":"url(static/yes.png)","width":"32px","height":"32px"});
                $(".checkbtn").removeAttr("disabled");
                go.removeClass("alert_r_1 tel_");
            }else{
                $(this).siblings("div").find("i").css({"background":"url(static/zsjx1.png)","width":"16px","height":"16px"});
                $(this).addClass("border_r");
                go.removeClass("tel_");
                go.addClass("tel_x_g");
            }
        }else if(text=='验证码'){
            var arr= $(this).val().match(/\d{6}/); /*正则表达式对input 检测*/
            if(arr!=null){
                $(this).siblings("div").find("i").css({"background":""});
                go.removeClass("alert_r_1 info_  info_x_g ");
            }else{
                $(this).siblings("div").find("i").css({"background":"url(static/zsjx1.png)","width":"16px","height":"16px"});
                go.removeClass("info_");
                go.addClass("info_x_g");
            }
        }else if(text=='设置密码'){
            var arr_sz= $(this).val().match(/\d{6,20}/); /*正则表达式对input 检测*/
            var arr_yw= $(this).val().match(/\w{6,20}/)
            if($(this).val()!=""){
                if(arr_sz!=null){
                    $(this).siblings("div").find("i").css({"background":"url(static/zsjx.png)","width":"16px","height":"16px"});
                    go.removeClass("pwd_x_g pwd_x_k")
                    go.addClass("pwd_z alert_r_1");
                }else{
                    if(arr_yw!=null){
                        $(this).siblings("div").find("i").css({"background":"url(static/zsjx.png)","width":"16px","height":"16px"});
                        go.removeClass("pwd_x_g pwd_x_k")
                        go.addClass("pwd_z_1 alert_r_1");
                    }else{
                        $(this).siblings("div").find("i").css({"background":"url(static/zsjx1.png)","width":"16px","height":"16px"});
                        $(this).addClass("border_r");
                        go.removeClass("pwd_");
                        go.addClass("pwd_x_g alert_r_1");
                    }
                }
            }else{
                $(this).siblings("div").find("i").css({"background":"url(static/zsjx1.png)","width":"16px","height":"16px"});
                $(this).addClass("border_r");
                go.removeClass("pwd_ pwd_x_g");
                go.addClass("pwd_x_k alert_r_1");
            }

        }else if(text=='确认密码'){
            var arr= $(this).val().match(/.{6,20}/); /*正则表达式对input 检测*/
            if(arr!=null){
                if($(this).val()==$('.pwd_index').val()){
                    $(this).siblings("div").find("i").css({"background":"url(static/yes.png)","width":"32px","height":"32px"});
                    go.removeClass("alert_r_1 cpwd_ cpwd_x_b cpwd_x_g");
                }else{
                    $(this).siblings("div").find("i").css({"background":"url(static/zsjx1.png)","width":"16px","height":"16px"});
                    $(this).addClass("border_r");
                    go.removeClass("cpwd_ cpwd_x_b");
                    go.addClass("cpwd_x_b alert_r_1");
                }
            }else{
                $(this).siblings("div").find("i").css({"background":"url(static/zsjx1.png)","width":"16px","height":"16px"});
                $(this).addClass("border_r");
                go.removeClass("cpwd_");
                go.addClass("cpwd_x_g alert_r_1");
            }
        }

    })
    var uname_post_ajax=$("#register input[name]");
    uname_post_ajax.blur(function(){
        let uname=$(this).val();
        let go=$(this).siblings("div").find("div");
        go.removeClass("user_ user_x_c");
        $.ajax({
            url:'http://127.0.0.1:4406/user/test_register',
            data:`uname=${uname}`,
            type:'post',
            dataType:'json',
            success: function(res) {
                let{state}=res;
                if(state!=200){
                    uname_post_ajax.addClass("border_r")                  
                    go.siblings("i").css({"background":"url(static/zsjx1.png)","width":"16px","height":"16px"});
                    go.addClass("user_x_c alert_r_1");
                }
            }
        })
    }) 
    
   
    $(".register_btn").on("click",function(e){
        e.preventDefault();

        var txt=$("#register>div>input")
        // console.log(txt[1].val())
        let count=0;
        let arr=[];
        txt.each(function(){
            if($(this).val()==''){
                $(this).focus();
                return false;
            }else{
                count++;
                arr[count]=$(this).val()
            }
        })
        if(count==5){
            $.ajax({
                url:'http://127.0.0.1:4406/user/register',
                data:`uname=${arr[1]}&phone=${arr[2]}&upwd=${arr[4]}`,
                type:'post',
                dataType:'json',
                success: function(res) {
                    let{state}=res;
                    console.log(res)
                    if(state==200){
                        inof($(".register_btn"),'注册成功！ 正在前往登陆👑')
                        setTimeout(function(){
                            window.location.href='http://127.0.0.1:4406/login_user.html';
                        },1000)
                    }else{
                        console.log(1)
                        inof($(".register_btn"),'注册失败！ 用户名已存在')
                    }
                }
            })
        }
        
    })
})