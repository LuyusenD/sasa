$.ajax({
    url:"http://176.137.16.189:4406/index/",
    type:"get",
	dataType:"jsonp",
	success: function(res) {
		var p=res
	html='',
	parent=document.querySelector("#box_body .carouselsx .list_img");
	for(var i=0;i<p.length;i++){
		var {bid,img,title,href}=p[i];
		html+=`
			<a href="${href}" title="${title}"><img src="${img}"/></a>
	     `
	 }
	parent.innerHTML=html;
	}        
})
