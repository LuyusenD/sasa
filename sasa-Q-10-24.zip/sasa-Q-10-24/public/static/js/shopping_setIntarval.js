$(function(){
    /*setInterval(function(){
        let count_inp=document.querySelector(".section_1 .content-text>.count>input");
        let count_val=parseInt(count_inp.value)
        let count_span=parseInt(document.querySelector(".section_1 .content-text>.count>span").innerHTML);
        if(count_val>count_span){alert(`库存不足！库存量为:${count_span}`);count_inp.value=count_span}else if(count_val<1){alert(`最低为购买为1`);count_inp.value=1}
        let val=$(".r-fixed-shop").find("li").length;
        $(".r-fiexd-1-2 b").html(val);
        $(".r-content-submit .shop_count").html(val);
        var vals=0;
        $(".shop_price").each(function(){
            vals+=parseFloat($(this).html())
        })
        $(".shop_prices").html(vals.toFixed(2));
     },100)*/
})