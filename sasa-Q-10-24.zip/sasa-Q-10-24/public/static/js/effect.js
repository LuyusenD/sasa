$(function(){
    $(".category-nav-item-1").hover(function(){
        //$(this).addClass("list_animated")
        //$(this).find("span:nth-child(2)").css("color","#FA3778");
        $(this).find("span:nth-child(1)").css("backgroundImage","url(./static/img/body/pc_categorym-02.png)");
        $(this).find(".class_Contents").css("display","block");
        $(this).find("span:nth-child(3)").addClass("list_nextRedico");
        let top=$(this).offset().top-$(".left_Cwh").offset().top;
        $(".class_Contents ").css("top",top)
    },function(){
        $(this).find(".class_Contents").css("display","none");
        //$(this).css("background","#FA3778");
        //$(this).find("span:nth-child(2)").css("color","#ffff");
        $(this).find("span:nth-child(1)").css("backgroundImage","url(./static/img/body/pc_categorym-01.png)");
    })
    /*��˺�ֲ�ͼ*/
    var index=0; //�ֲ����Ʊ�
    /*������ť*/
    $(".carouselsx ul li").hover(function(){
        index=$(this).index();
        index--;
        autoplay();
        $(".carouselsx ul li").stop().animate({left:-index*1920+"px"},1000);
        $(this).addClass("active").siblings().removeClass("active");

    })
    /*��ʱ��*/
    var Time=setInterval(autoplay,2500)
    function autoplay(){
        index++;
        $(".carouselsx ul li").eq(index).addClass("active").siblings().removeClass("active");
        if(index == 6){
            index=0;
            $(".carouselsx .list_img").css("left","0px");
        }
        $(".carouselsx .list_img").stop().animate({left:-index*1920+"px"},1300);
        if(index==5){
            $(".carouselsx ul li").eq(0).addClass("active").siblings().removeClass("active");
        }else{
            $(".carouselsx ul li").eq(index).addClass("active").siblings().removeClass("active");
        }
    }
    var hover1=function(){
        clearInterval(Time)
    };
    var hover2=function(){
        Time=setInterval(autoplay,2500)
    };
    $(".carouselsx .list_img").hover(hover1,hover2);

/***************************************************************************************************购物车*/
    var i=1;
    /*right fiexd shop*/
    $(".r-fixed-shop>div>ul").click(function(e){
        if(e.target.nodeName=="Z")
        e.target.parentNode.remove()
    })
    
    
   
 /***************************************************************************************************购物车*/
})
/*�л���½��ʽ*/
$(function(){
var $ptdl2=$("#putdl2");
var $ptdl1=$("#putdl1");
var $login_2=$("#login_2");
var $active=$(".active");
var $login_1=$("#login_1");
var promt_Reg=$(".promt_Reg");
$ptdl2.click(()=>{
    $active.animate({
       left:250,
       width:70
    },500)
$login_2.fadeIn(700);
$login_1.fadeOut(700);
promt_Reg.slideUp(500);
})
$ptdl1.click(()=>{
    $active.animate({
        left:79,
        width:65
    },700)
promt_Reg.slideUp(500);
$login_1.fadeIn(700);
$login_2.fadeOut(700);
})


})
/*�ҹ̶� Top*/
$(window).scroll(function(){
    var Top= $("body,html").scrollTop();
    Top>100?$('#Top').fadeIn(1000):$('#Top').fadeOut(1000);

})
/*�й̶�Top ����������*/
var fun=(function(){
    return function(){
        $("html,body").animate({scrollTop:0},500)
    }
})()



$(function() {
    var $login_2Inp = $(".inut_1");
    var promt_Reg = $(".promt_Reg");
        $(".general").children(".login_1").on("blur", ".inut_1", function () {
            var inut_1=$(this);
            var phone_Reg = /1[3-8]\d{9}/;
            var mailbox_Reg = /(.*@.*?)\.(com|cn|net)(\.cn)?/;
            var userhonpe2 = inut_1.val();
            if (mailbox_Reg.test(userhonpe2) || phone_Reg.test(userhonpe2)) {
                promt_Reg.slideUp(100);
                inut_1.addClass("success_Ico");
                $(".button_2").css("background", "#FF6E24")
            } else {
                promt_Reg.slideDown(100);
                inut_1.removeClass("success_Ico");
                $(".button_2").css("background", "#FF9CB1")
            }

        })
})


