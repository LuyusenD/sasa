/*(function(){
    var u_cookie=decodeURI(document.cookie).split("|");
    var hone=document.querySelector(".hone");
    var form=document.forms[0];
    var age=document.getElementsByName("age")
    var  tx_img=document.querySelector(
        ".tx_img"
    );
   (async function(){
        var res=await ajax({
          url:"http://176.137.16.189:4406/user/set_user",
          type:"get",
          data:`uid=${u_cookie[0]}`,
          dataType:"json"
        })
        var {user_email,user_username,user_phone,user_address,user_gender,user_ico,user_money}=res[0];
        hone.innerHTML=user_username;
        form.children[0].children[1].value=user_email;
        form.children[2].children[1].value=user_username;
        form.children[4].children[1].value=user_phone;
        form.children[6].children[1].value=user_address;
        if(user_gender==1){ 
            age[0].checked=true
           }else{age[1].checked=true};  
        console.log(age[1])
        var img=document.createElement("img");
            img.setAttribute("src",user_ico);
            tx_img.appendChild(img);
})()
})()*/
