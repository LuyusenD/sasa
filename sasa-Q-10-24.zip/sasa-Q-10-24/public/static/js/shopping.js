/**
 * Created by web on 2018/9/6.
 */
$(function(){
    $('.content-img-sm li').hover(function(){
        let src=$(this).find("img").attr("src");
        $(".content-img-lg img").attr("src",src);
        $("#op_big_box img").attr("src",src);
    })
    $('.count button').click(function(){
        let val= $(".count input").val();
        if($(this).val()!="-"){
            val++;
            $(".count input").val(val);
        }else if(val>1){
            val--;
            $(".count input").val(val);
        }
    })
    $(".count span").mouseover(function(){
        $(".erweima").stop(true).slideDown();
        $(".erweima img").animate({"top":"0px"});
        $(".count span").mouseout(function(){$(".erweima").stop(true).slideUp();$(".erweima img").animate({"top":"170px"},-1000);
        })
    })
    $(".grade div>a").click(()=>{
        let i4="static/img/body/shop4.png";
        let i5="static/img/body/shop5.png";
        if($(".grade div>a img").attr("src")==i4){
            $(".grade div>a img").attr("src",i5)
        }else{
            $(".grade div>a img").attr("src",i4)
        }
    })
    $(window).scroll(()=>{
        var top=$("html,body").scrollTop();
        var H=document.body.clientHeight-1020;
        if(top>1324&&top<H){
            $(".s3_list_").css({"position":"fixed","top":"0","width":"268px"});
            $(".s3_cont1").css({"position":"fixed","top":"0","width":"67.8%","box-shadow":"0 1px 2px #999"});
        }else{
            $(".s3_list_").css({"position":"relative"})
            $(".s3_cont1").css({"position":"relative",'width':'100%'});
        }
    })
    $(".s3_cont1 li").click(function(){
        var top=$("html,body").scrollTop();
        var H=document.body.clientHeight-1030;
        if(this.innerHTML=="商品参数"){
            $("html,body").stop(true).animate({"scrollTop":"1324"},500);
            $(this).siblings("i").animate({"left":"0px"});
        }else if(this.innerHTML=="商品详情"){
            $("html,body").stop(true).animate({"scrollTop":"1605"},700);
            $(this).siblings("i").animate({"left":"132px"});
        }else{
            $("html,body").stop(true).animate({"scrollTop":H},1000);
            $(this).siblings("i").animate({"left":"264px"});
        }
    })

    let smBox=$(".content-img-lg"),
        op_div=$(".content-img-lg #op_div"),
        bigBox=$("#op_big_box"),
        bigImg=$("#op_big_box img");
    smBox.mouseover(()=>{
        // let src=$('.section_1>.row>.col-s .content-img-lg>img ').attr("src");
        // op_div.css("background",`url(${src})`)
        // console.log(src)
        op_div.show()
        bigBox.show()
        $("#op_mtk").show()
        $(".content-img-lg").css({"z-index":11})
    })
    smBox.mouseout(()=>{
        op_div.hide()
        bigBox.hide()
        $("#op_mtk").hide();
        $(".content-img-lg s").css({"z-index":12})
    })
    smBox.mousemove((e)=>{
        var left=e.pageX-smBox.offset().left-op_div.innerWidth()/2;
        var top=e.pageY-smBox.offset().top-op_div.innerHeight()/2;
        if(left<0)left=0
        else if(left>215) left=215
        if(top<0)top=0
        else if(top>215) top=215
        op_div.css({"left":left,"top":top})
        var leftS=-(left/(smBox.innerWidth()-op_div.innerWidth()))*(bigImg.innerWidth()-bigBox.innerWidth());
        var topS=-(top/(smBox.innerHeight()-op_div.innerHeight()))*(bigImg.innerHeight()-bigBox.innerHeight());
        bigImg.css({"left":leftS,"top":topS})
    })

    $(".content-img-lg i").click(function(){
        $("#video").show();
        //$("#video video").attr("autoplay","play");
        $(this).hide()
        $(".content-img-lg s").show();
        op_div.hide()
    })
    $(".content-img-lg s").click(function(){
        $("#video").hide();
        $(this).hide()
        op_div.show()
        $(".content-img-lg i").show()
    })

    $(".count .mt-4 a").click(function(){
        inof($(".count .mt-4 a"),"加入购物车成功!")
    })

})