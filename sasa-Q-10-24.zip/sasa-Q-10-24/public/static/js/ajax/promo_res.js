$(function(){
   var kag=0;
   function page(pon=0){
    $.ajax({
	   url:`http://127.0.0.1:4406/promo?pon=${pon}`,
	   type:"get",
       dataType:"json",
	  success: function(res){
	    var {img0,img1,img2,img3,price}=res['products'];
		 var html='';
        var ac_shop=$(".ac_shop");
        var shop_ative=$(".shop_ative");
        for(var {img0,img1,brand,img2,img3,price,yprice,discount,sid} of res['products'] ){
      console.log(sid)
              html+=`
              <div class="shop_ative "> 
      <div class="s3_content">
             <div class="s3_item">
             <div class="s3_item_1"><a href="shopping.html?sid=${sid}"><img src="${img0}"/></a></div>
             <div class="s3_item_2 list-unstyled float-right">
             <li><img src="${img0}"/></li>
             <li><img src="${img2}"/></li>
             <li><img src="${img3}"/></li>
            </div>
            <div class="s3_item_3">
        <span class="text_F63D81 my_font_15r">${yprice}<s class="text-secondary small">${price}</s></span>
            <span class="text_C69A62">${discount}</span>
            </div>
            <div class="s3_item_4">
             <span><b>香港特快直送 零扣关</b><b>COAST TOCOAST</b></span>
             <p class="my_font_9r"><a href="shopping.html?sid=${sid}" class="nav-link p-0">${brand}</a></p>
             <p class="mt-4"></p>
             </div>
             <div class="s3_item_5">
             <a href="shopping.html?sid=${sid}">加入购物车</a>
             </div>
             </div>
             </div>
      </div>`
      }
      $(".ac_shop").html(html)
      $(`<script src="static/js/promo.js"></script>`).appendTo("head")
      var pageYm=$('.pageYm');
      var html;
      html=`   <li class="prev_nv nav-item border "><a class="nav-link " href="">上一页</a></li>`;
      for(var i=0;i<res['pageCount'];i++){
        html+=` <li class="nav-item border ml-1  "><a class="nav-link" href="">${1+i}</a></li>`;
        
      }
      kag=pon;
      var html;
      html+=`   <li class="nav-item border next_nv "><a class="nav-link" href="">下一页</a></li>`;
      pageYm.html(html);
      kag=="0" ? $(".prev_nv a").addClass("disabled"):'';
      if(kag>=res['pageCount']-1){
      $(".next_nv a").addClass("disabled");
      }
    }
    })
}
var res=page(0)
var pageYm=$('.pageYm');
pageYm.on("click","a",function(e){
    e.preventDefault();
    var pon=$(this).html();
    if(pon!="上一页"&&pon!="下一页"){
        pon--;
        page(pon);
    }

    if(pon=="上一页"){
        kag--;
        page(kag--)
     };
     if(pon=="下一页"){
        kag++;
        page(kag++);
     };
})

})