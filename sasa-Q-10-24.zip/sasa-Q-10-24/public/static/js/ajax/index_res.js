
/*(async function(){
	var res=await ajax({
        url:"http://127.0.0.1:4406/index/",
        type:"get",
        dataType:"json"        
    })
	var p=res
		html='',
		parent=document.querySelector(".carouselsx .list_img");
		for(var i=0;i<p.length;i++){
			var {bid,img,title,href}=p[i];
			html+=`
				<a href="${href}" title="${title}"><img src="${img}"/></a>
		     `
		 }
		parent.innerHTML=html;

	var res=await ajax({
		url:"http://127.0.0.1:4406/index/DayLook",
		type:"get",
		dataType:"json"
	})
	var p=res,
		html='',
		parent=document.querySelectorAll("#shop .section_2>div>.d-flex");	
	for(var i=0;i<parent.length;i++){
		var{did,img,title,stitle,price,href}=p[i];
		html=`<div>
                 <img src="${img}"/>
              </div>
              <div class="d-flex justify-content-center flex-column align-items-center section_2_1 ">
                 <h5><a href="${href}">${title}</a></h5>
                 <h6><a href="${href}">${stitle}</a></h6>
                 <h6 class="small"><a href="${href}">${price}</a></h6>
                 <a href="${href}" class="section_a_linear_z">立即疯抢</a>
			  </div>`;
		parent[i].innerHTML=html;
	}

	var res=await ajax({
		url:"http://127.0.0.1:4406/index/Limited",
		type:"get",
		dataType:"json"
	})
	var p=res,
		html='',
		parent=document.querySelectorAll("#shop>.section_3>div>div.d-flex");
	for(var i=0;i<parent.length;i++){
		var{img,discount,title,delivery,stitle,price,yprice,sell,href}=p[i];
		html=`<div class="col-7 p-0" >
                    <a href="${href}"><img src="${img}"/></a>
                    <b class="section_3_discont">
                        ${discount}<span class="small">折</span>
                    </b>
              </div>
              <div class="col-6 section3_2 pl-5">
                    <div class="section_3_data">剩余 </div>
                    <div><img src="static/img/body/shuangy.png"/>${title}</div>
                    <div><b class="b">${delivery}</b>${stitle}</div>
                    <div><span>￥</span><span>${price}</span> <s class="small"> ${yprice}</s></div>
                    <div>
                        <div>已售 <span>${sell}</span>件</div>
                        <a href="${href}" class="section_a_linear_z">马上抢购</a>
                    </div>
              </div>`;
		parent[i].innerHTML=html;
	}

	var res= await ajax({
		url:'http://127.0.0.1:4406/index/Ranking',
		type:'get',
		dataType:'json'
	}),
	parent=document.querySelectorAll("#shop .section_4>div>.section__4");
	for(var key=0,s=0;key<3;key++){
		html='';
		for(var i=0;i<res.slice(0,5).length;i++){
			var{img,title,delivery,price,yprice,sell,href}=res[s]
			html+=`
				<div class="row">
					<div class="col-3 ml-3">
						<span class="one"></span>
						<a href="${href}"><img src="${img}" class="w-100"/></a>
					</div>
					<div class="col-8 section_4_2">
						<a href="${href}"><b class="b">${delivery}</b>${title}</a>
						<div class="d-flex align-items-baseline justify-content-between">
							<div><span>￥</span><span>${price} </span> <s class="small"> ${yprice}</s></div>
							<div><div class="text-muted font_8">已售 <span>${sell}</span></div></div>
						</div>
					</div>
				</div>	
			`;
			s++;
		}
		parent[key].innerHTML+=html
	} 
	
	/*var res=await ajax({
		url:'http://176.137.16.189:4406/index/NewArrival',
		type:'get',
		dataType:'json'
	});
	html='';
	parent=document.querySelectorAll("#shop .section_5>div")[0];
	
	for(var i=0;i<res.length;i++){
		var{img,origin,origin_name,title,delivery,price,yprice,href}=res[i]
		html+=`<div>
			 <span>新品上市</span>
                <a href="${href}"><img class="w-100" src="${img}"/></a>
          <div class="section_4_2">
                    <span><img src="${origin}" class="w-25"/> ${origin_name}</span>
                    <a href="${href}"><b class="b">${delivery}</b>${title}</a>
                    <div class="d-flex align-items-baseline justify-content-between mt-3">
                        <div><span>￥</span><span>${price} </span> <s class="small"> ${yprice}.0</s></div>
                    </div>
                </div>
		  </div>`;
	}
	parent.innerHTML=html
})()
*/