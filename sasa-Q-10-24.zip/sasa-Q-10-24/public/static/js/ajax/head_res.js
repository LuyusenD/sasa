/*
$(function(){
    $(`<link rel="stylesheet" href="static/css/bootstrap.css"/>`).appendTo("head");
    $(`<link rel="stylesheet" href="static/css/header.css"/>`).appendTo("head");
    $(`<link rel="stylesheet" href="static/css/select1.css"/>`).appendTo("head");
    $(`<style>
    .all_type:hover~.BleftX>.left_Cwh{display:block !important;}
    .BleftX:hover .left_Cwh{display:block !important;}</style>`).appendTo("head");
    /*.left_Cwh{display:none}*/
 /*   var u_cookie=decodeURI(document.cookie).split("|");
    $.ajax({
        url:'header_.html',
        type:'get',
        success: function(res) {
			
         /*   $(res).replaceAll("#header");
			头部信息加载
			var span=document.querySelector(
			 ".navbar .navbar-brand"
			)
				function isuser(money,ico){
			var span=document.querySelector(
				 ".navbar .navbar-brand"
				)
				var u_cookie=decodeURI(document.cookie).split("|");
				var html=`
				 欢迎光临莎莎网！&nbsp;&nbsp;&nbsp;
				 <a href="Member.html">${u_cookie[1]}</a>&nbsp;&nbsp;&nbsp;
				 或
				 &nbsp;&nbsp;<a  href="register.html">退出</a>
				<div class="user_ico"><div class="user_img"><img src="${ico}"></div><span class="font_money">余额:&nbsp;&nbsp;&nbsp;¥${money.toFixed(2)}</span><span class="font_vip">级别：普通会员</span><span class="font_info">莎莎祝你，每天生活愉快。</span></div>`;
			span.innerHTML=html;*/
		/*	}
			var search_top=$("#search_top");
			var $val=search_top.prev()
			/*搜索商品*/
		/*	search_top.click(function(){		
                location.href=`http://176.137.16.189:4406/shopping/search_top.html?kw=${$val.val()}`
			})
			$val.keyup(function(e){
			   if(e.keyCode=="13")
                  search_top.click()
            })
		
           
			$.ajax({
			    url:"http://127.0.0.1:4406/user/set_user",
			    type:"get",
				data:`uid=${u_cookie[0]}`,
				dataType:"json",
			    success:function(res){
					var {user_ico,user_money}=res[0];
					isuser(user_money,user_ico)/*nav金额与头像*/
			/*	}
			
		/*	})

            $.ajax({
                url:"http://127.0.0.1:4406/index/list_nav",
                type:"get",
                dataType:"json",
                success:function(res){
                    var p=res,
	                list='',
                    parent=$("#box_body .selfclass .class_Contents .list-unstyled");
	                for(var i=0;i<p.slice(0,6).length;i++){
	                	var{title,l1,l2,l3,l4,l5,l6,l7,l8,href}=p[i]
	                	list+=`
	                		<li class="border-0 ">
	                			<h6 class="text-muted">${title}</h6>
	                			<a href="${href}">${l1}</a>
	                			<a href="${href}">${l2}</a>
	                			<a href="${href}">${l3}</a>
	                			<a href="${href}">${l4}</a>
	                			<a href="${href}">${l5}</a>
	                			<a href="${href}">${l6}</a>
	                			<a href="${href}">${l7}</a>
	                			<a href="${href}">${l8}</a>
	                		</li>`
								
	                }
                    
                    list1='';
		            for(var i=0,n=6;i<p.slice(6,9).length;i++){
			            var{title,l1,l2,l3,l4,l5,l6,l7,l8,href}=p[n];
			            n++;
			            list1+=`
			            	<li class="border-0 ">
			            		<h6 class="text-muted">${title}</h6>
			            		<a href="${href}">${l1}</a>
			            		<a href="${href}">${l2}</a>
			            		<a href="${href}">${l3}</a>
			            		<a href="${href}">${l4}</a>
			            		<a href="${href}">${l5}</a>
			            		<a href="${href}">${l6}</a>
			            		<a href="${href}">${l7}</a>
			            		<a href="${href}">${l8}</a>
			            	</li>`
					}
					

		            for(let sss=2,n=9;sss<parent.length;sss++){
		            	list2='';
		            	for(var i=0;i<p.slice(n,n+1).length;i++){
		            		var{title,l1,l2,l3,l4,l5,l6,l7,l8,href}=p[n];
		            		list2+=`
		            			<li class="border-0 ">
		            				<h6 class="text-muted">${title}</h6>
		            				<a href="${href}">${l1}</a>
		            				<a href="${href}">${l2}</a>
		            				<a href="${href}">${l3}</a>
		            				<a href="${href}">${l4}</a>
		            				<a href="${href}">${l5}</a>
		            				<a href="${href}">${l6}</a>
		            				<a href="${href}">${l7}</a>
		            				<a href="${href}">${l8}</a>
		            			</li>`
		            	}
						n++;
						parent[0].innerHTML=list;
		           		parent[1].innerHTML=list1;
		            	parent[sss].innerHTML=list2;
		            }
                        
                }
            })

        }

    })
    $(`<script src="static/js/effect.js"></script>`).appendTo("head");
    $.ajax({
		url:'footer.html',
		type:'get',
		success:function(res){
    		$(`<link rel="stylesheet" href="static/css/footer.css"/>`).appendTo("head")			
			$("#footer").html(res)
		}
	})
     
	


})

*/