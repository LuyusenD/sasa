/*
功能已在vue实现 暂注释
$(function(){
    var s='';
    var ajax_shop=function (index=0,pno=0,data=''){
        s=data
        $.ajax({
            url:'http://127.0.0.1:4406/shopping/details',
            type:'get',
            data:`data=${data}`,
            dataType:'json',
            success: function(res) {
                 var p=res.slice(index,index+6),
                     html=``,
                     parent=$("#search_3 .ac_shop");
                for(var key of p){
                    var{title,brand,sid,price,yprice,discount,img0,img1,img2}=key;
                    html+=`<div class="shop_active">
                    <div class="search_3_content ">
                        <div class="s3_content">
                                <div class="s3_item">
                                    <div class="s3_item_1"><a href="/shopping.html?sid=${sid}"><img src="${img0}"/></a></div>
                                    <div class="s3_item_2 list-unstyled float-right">
                                        <li><img src="${img0}"/></li>
                                        <li><img src="${img1}"/></li>
                                        <li><img src="${img2}"/></li>
                                    </div>
                                    <div class="s3_item_3">
                                        <span class="text_F63D81 my_font_15r">￥${price}.0 <s class="text-secondary small"> ${yprice}</s></span>
                                        <span class="text_C69A62">${discount}折</span>
                                    </div>
                                    <div class="s3_item_4">
                                        <span><b>香港特快直送 零扣关</b></span>
                                        <p><b>${brand}</b></p>
                                        <p class="my_font_9r"><a href="#" class="nav-link p-0">${title}</a></p>
                                        <p class="mt-4"></p>
                                    </div>
                                    <div class="s3_item_5">
                                        <a href="/shopping.html?sid=${sid}">加入购物车</a>
                                    </div>
                                </div>
                        </div>
                    </div>
                </div>`
                }
                parent.html(html)
                $(`<script src="static/js/Details.js"></script>`).appendTo("head");
                parent=$(".nav_foot>ul");
                html=`<a href="#" class="${pno==0?'disabled':''}">上一页</a>`;
                let count=Math.ceil(res.length/6);
                for(var i=1;i<=count;i++){
                    html+=`<a href="#" class="${pno==i-1?'nav_foot_active':''}">${i}</a>`
                }
                html+=`<a href="#" class="${pno==count-1?'disabled':''}">下一页</a>`;
                parent.html(html)
            }
        })

    }
    $("#search_3 .s3_opacity_list").on("click","a",function(e){
        e.preventDefault();
        let vals=$(this).html().slice(23);
        if(vals=='面部保养'){
            ajax_shop(0,0,1)
        }else if(vals=='彩妆'){
            ajax_shop(0,0,2)
        }else if(vals=='香水'){
            ajax_shop(0,0,3)
        }else if(vals=='健康'){
            ajax_shop(0,0,4)
        }else if(vals=='个人护理'){
            ajax_shop(0,0,5)
        }else if(vals=='男人专区'){
            ajax_shop(0,0,6)
        }else if(vals=='婴儿护理专区'){
            ajax_shop(0,0,7)
        }
    })
    $(".all_listshop").on("click","a",function(e){
        e.preventDefault();
        ajax_shop(0)
    })
    $(".nav_foot").on("click","a",function(e){
        e.preventDefault()
        var i=6,
            vals=$(this).html(),
            prev=$(".nav_foot>ul>a:first()");
        if(vals>1)
            prev.removeClass("disabled")
        else
            prev.addClass("disabled")
        if($(this).html()=='上一页'){
            let counts=$(this).siblings(".nav_foot_active").html();
            ajax_shop(i*(counts-2),counts-2,s);
            $(this).siblings().removeClass("nav_foot_active")
            $(this).addClass('nav_foot_active')
        }else if($(this).html()=='下一页'){
            console.log(1)
            var counts=$(this).siblings(".nav_foot_active").html();
            console.log($(this).siblings(".nav_foot_active"))
            
            ajax_shop(i*(counts),counts,s);
            $(this).siblings().removeClass("nav_foot_active")
            $(this).addClass('nav_foot_active')
        }else{
           // console.log(s)
            ajax_shop(i*(vals-1),vals-1,s);
            $(this).siblings().removeClass("nav_foot_active")
            $(this).addClass('nav_foot_active');
        }
  
            $("html,body").animate({scrollTop:595},500)
         
        })

    // let $ul=$("#search_3 .nav_shop>ul")
    // $ul.on("click","li",function(){
    //     let vals=$(this).children("z").html();
    //     if(vals=="销量")console.log(1)
    //     console.log()
    // })
})