(async function(){
    var url= location.search,i=url.indexOf("sid"),
        sid=parseInt(url.slice(i).split("=")[1]);
    var res=await ajax({
        url:'http://127.0.0.1:4406/shopping',
        type:'get',
        data:`sid=${sid}`,
        dataType:'json'        
    })
    var p=res[0],
        html="";

        console.log(p)
        let img_arr=[p.img0,p.img1,p.img2,p.img3]
        new Vue({
            el:"#section_1",
            data:{
                p,img_arr
            }
        });
        
        var{brand,color,day,discount,effect,emailprice,img1,img0,img2,img3,inventory,price,semailprice,sid,shopId,spec,state,title,video,xqimg0,xqimg1,xqimg3,xqimg2,xqimg4,yprice}=p;


    parent=document.querySelector(".s3_content>.s3_cont2>div");
    html=`<p><span>商品编号：</span>${shopId}</p>
    <p><span>商品品牌：</span>${brand}</p>
    <p><span>商品名称：</span>${title}</p>
    <p><span>商品规格：</span>${spec}</p>
    <p><span>原产国家：</span>${state}（具体产地以收到实物为准）</p>`;
    parent.innerHTML=html;
    parent=document.querySelector(".s3_content>.s3_cont3");
    html=`<p>商品详情</p>
    <img src="${xqimg0}"/>
    <img src="${xqimg1}"/>
    <img src="${xqimg2}"/>
    <img src="${xqimg3}"/>
    <img src="${xqimg4}"/>`;
    parent.innerHTML=html;
    parent=document.head.children[6];
    html=`${brand}${title}`;
    parent.innerHTML=html;
    

    // var sid=Math.random()*50;

    var res=await ajax({
        url:'http://127.0.0.1:4406/shopping/like',
        type:'get',
        dataType:'json'        
    })

    html='',
    parent=document.querySelector(".section_2>.s2_list")
    for(var i=0;i<5;i++){
        let shop_count=parseInt(Math.random()*50)
        let{title,price,img0,sid}=res[shop_count]
        html+=`<div><a href="/shopping.html?sid=${sid}"><img src="${img0}"/></a> <a href="#">${title}</a> <p>￥${price}.00 </p></div>`  
    }
    parent.innerHTML=html    
})()