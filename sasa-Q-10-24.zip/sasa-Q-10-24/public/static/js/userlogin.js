
$(function() {
  checkico($(".div_info input"));
  var phone="请重新输入用户名或手机号，不能为空"
  var eifo='请输入✔的11号手机号码或者邮箱进行登录'
 if($(".inut_1")[0]!==undefined){
  info({
    elem:$(".inut_1"),
    top:33,
    left:294,
    e_rr:eifo,
    n_ull:phone,
    phme:1
  })
		
  var pass="请重新输入密码并长度至少6位，不能为空"
  var eiof1='请输入至少6位并且正确✔的密码'
  info({
    elem:$(".pass"),
    top:34,
    left:294,
    e_rr:eiof1,
    n_ull:pass,
    reg:/^\d{6}$/
  })
  $(".inut_1").one("click",function(){
    plays($(this),120);
  })
  $(".pass")
  .one("click",function(){
   plays($(this),120);
  })
  var submit1=document.getElementsByClassName("submit1")[0];
  var user_password=document.getElementsByName("user_password")[0];
  var user_phone=document.getElementsByName("user_phone")[0];
submit1.onclick=function(){
    (async function(){
        var res=await ajax({
          url:"http://127.0.0.1:4406/user/login_user",
          type:"get",
          data:`user_phone=${user_phone.value}&user_password=${user_password.value}`,
          dataType:"json"
        })
        if(!(res.state==404)){
          var {user_username,user_uid}=res[0]
          var t=`欢迎,   ${user_username}来到莎莎购物网`
          inof($(".top_info"),t)
           var time=setTimeout(() => {
           var userContent=`${user_uid}|${user_username}`
            document.cookie=encodeURI(userContent);
            location.href = "/";
          }, 1500);
          time=null;
        }else{
          var t="账号或密码错误请重新输入。"
           inof($(".top_info"),t)
        }
      })() 
}}
})



